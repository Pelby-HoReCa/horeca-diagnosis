import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect } from '@react-navigation/native';
import { Asset } from 'expo-asset';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Dimensions, FlatList, Image, Platform, ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { SvgXml } from 'react-native-svg';
import AnimatedPressable from '../components/AnimatedPressable';
import { DEFAULT_BLOCKS, DiagnosisBlock } from '../data/diagnosisBlocks';
import questionsData from '../data/questions.json';
import { palette, radii, spacing, typography } from '../styles/theme';
import { getCurrentUserId, loadUserBlocks, loadUserQuestionnaire, saveUserBlocks } from '../utils/userDataStorage';

const logo = require('../../assets/images/logo-pelby.png');
const screenWidth = Dimensions.get('window').width;
const cardWidth = screenWidth - spacing.md * 2;

export default function SelfDiagnosisBlocksScreen({ navigation }: any) {
  const [restaurantName, setRestaurantName] = useState('Проект');
  const [city, setCity] = useState<string>('');
  const [projectAvatarUri, setProjectAvatarUri] = useState<string | null>(null);
  const [cityIconSvg, setCityIconSvg] = useState<string>('');
  const [helpButtonIconSvg, setHelpButtonIconSvg] = useState<string>('');
  const [blocks, setBlocks] = useState<DiagnosisBlock[]>([]);
  const [loading, setLoading] = useState(true);
  const flatListRef = useRef<FlatList>(null);
  const scrollViewRef = useRef<ScrollView>(null);
  const [refreshIconSvg, setRefreshIconSvg] = useState<string>('');
  const [addIconSvg, setAddIconSvg] = useState<string>('');
  const [activeTab, setActiveTab] = useState<string>('Все');
  // Иконки для блоков
  const [coinsIconSvg, setCoinsIconSvg] = useState<string>('');
  const [colorsIconSvg, setColorsIconSvg] = useState<string>('');
  const [chartBarLineIconSvg, setChartBarLineIconSvg] = useState<string>('');
  const [arrowRightIconSvg, setArrowRightIconSvg] = useState<string>('');
  const [fileIconSvg, setFileIconSvg] = useState<string>('');
  const [marketingIconSvg, setMarketingIconSvg] = useState<string>('');
  const [computerSettingsIconSvg, setComputerSettingsIconSvg] = useState<string>('');
  const [userMultipleIconSvg, setUserMultipleIconSvg] = useState<string>('');
  const [dishWasherIconSvg, setDishWasherIconSvg] = useState<string>('');
  const [legalDocumentIconSvg, setLegalDocumentIconSvg] = useState<string>('');
  const [chartIncreaseIconSvg, setChartIncreaseIconSvg] = useState<string>('');

  useEffect(() => {
    console.log('Компонент загружен, инициализируем...');
    loadBlocks();
    loadProfileData();
    loadIcons();
  }, []);

  const loadProfileData = async () => {
    try {
      const userId = await getCurrentUserId();
      
      if (userId) {
        const questionnaireData = await loadUserQuestionnaire(userId);
        if (questionnaireData && questionnaireData.restaurantName && questionnaireData.restaurantName.trim()) {
          setRestaurantName(questionnaireData.restaurantName);
        } else {
          setRestaurantName('Проект');
        }
        
        // Загружаем город
        if (questionnaireData && questionnaireData.city) {
          setCity(questionnaireData.city);
        }
      } else {
        setRestaurantName('Проект');
      }
      
      const savedProjectAvatar = await AsyncStorage.getItem('projectAvatar');
      if (savedProjectAvatar) {
        setProjectAvatarUri(savedProjectAvatar);
      }
    } catch (error) {
      console.error('Ошибка загрузки данных профиля:', error);
    }
  };

  const loadIcons = async () => {
    // Загружаем SVG иконку для города
    const loadCityIcon = async () => {
      try {
        const iconAsset = Asset.fromModule(require('../../assets/images/arrow-down-city.svg'));
        await iconAsset.downloadAsync();
        if (iconAsset.localUri) {
          const response = await fetch(iconAsset.localUri);
          const fileContent = await response.text();
          setCityIconSvg(fileContent);
        }
      } catch (error) {
        console.error('Ошибка загрузки SVG иконки города:', error);
      }
    };
    
    // Загружаем SVG иконку для кнопки помощи
    const loadHelpButtonIcon = async () => {
      try {
        const iconAsset = Asset.fromModule(require('../../assets/images/help-button-icon.svg'));
        await iconAsset.downloadAsync();
        if (iconAsset.localUri) {
          const response = await fetch(iconAsset.localUri);
          const fileContent = await response.text();
          setHelpButtonIconSvg(fileContent);
        }
      } catch (error) {
        console.error('Ошибка загрузки SVG иконки кнопки помощи:', error);
      }
    };
    
    loadCityIcon();
    loadHelpButtonIcon();
    
    // Загружаем SVG иконки для секции "Общая эффективность"
    const loadEfficiencyIcons = async () => {
      try {
        // Иконка обновления (часов)
        const refreshAsset = Asset.fromModule(require('../../assets/images/refresh-icon.svg'));
        await refreshAsset.downloadAsync();
        if (refreshAsset.localUri) {
          const response = await fetch(refreshAsset.localUri);
          const fileContent = await response.text();
          setRefreshIconSvg(fileContent);
        }
        
        // Иконка добавления (плюсик)
        const addAsset = Asset.fromModule(require('../../assets/images/add-icon.svg'));
        await addAsset.downloadAsync();
        if (addAsset.localUri) {
          const response = await fetch(addAsset.localUri);
          const fileContent = await response.text();
          setAddIconSvg(fileContent);
        }
      } catch (error) {
        console.error('Ошибка загрузки SVG иконок эффективности:', error);
      }
    };
    
    // Загружаем иконки блоков
    const loadBlockIcons = async () => {
      try {
        // Иконка финансов
        const coinsAsset = Asset.fromModule(require('../../assets/images/coins-icon.svg'));
        await coinsAsset.downloadAsync();
        if (coinsAsset.localUri) {
          const response = await fetch(coinsAsset.localUri);
          const fileContent = await response.text();
          setCoinsIconSvg(fileContent);
        }
        
        // Иконка концепции
        const colorsAsset = Asset.fromModule(require('../../assets/images/colors-icon.svg'));
        await colorsAsset.downloadAsync();
        if (colorsAsset.localUri) {
          const response = await fetch(colorsAsset.localUri);
          const fileContent = await response.text();
          setColorsIconSvg(fileContent);
        }
        
        // Иконка управления
        const chartBarLineAsset = Asset.fromModule(require('../../assets/images/chart-bar-line-icon.svg'));
        await chartBarLineAsset.downloadAsync();
        if (chartBarLineAsset.localUri) {
          const response = await fetch(chartBarLineAsset.localUri);
          const fileContent = await response.text();
          setChartBarLineIconSvg(fileContent);
        }
        
        // Иконка стрелочки
        const arrowAsset = Asset.fromModule(require('../../assets/images/arrow-right-s-line.svg'));
        await arrowAsset.downloadAsync();
        if (arrowAsset.localUri) {
          const response = await fetch(arrowAsset.localUri);
          const fileContent = await response.text();
          setArrowRightIconSvg(fileContent);
        }
        
        // Иконка меню (file)
        const fileAsset = Asset.fromModule(require('../../assets/images/file-icon.svg'));
        await fileAsset.downloadAsync();
        if (fileAsset.localUri) {
          const response = await fetch(fileAsset.localUri);
          const fileContent = await response.text();
          setFileIconSvg(fileContent);
        }
        
        // Иконка маркетинга
        const marketingAsset = Asset.fromModule(require('../../assets/images/marketing-icon.svg'));
        await marketingAsset.downloadAsync();
        if (marketingAsset.localUri) {
          const response = await fetch(marketingAsset.localUri);
          const fileContent = await response.text();
          setMarketingIconSvg(fileContent);
        }
        
        // Иконка операций (computer-settings)
        const computerSettingsAsset = Asset.fromModule(require('../../assets/images/computer-settings-icon.svg'));
        await computerSettingsAsset.downloadAsync();
        if (computerSettingsAsset.localUri) {
          const response = await fetch(computerSettingsAsset.localUri);
          const fileContent = await response.text();
          setComputerSettingsIconSvg(fileContent);
        }
        
        // Иконка клиентского опыта (user-multiple)
        const userMultipleAsset = Asset.fromModule(require('../../assets/images/user-multiple-icon.svg'));
        await userMultipleAsset.downloadAsync();
        if (userMultipleAsset.localUri) {
          const response = await fetch(userMultipleAsset.localUri);
          const fileContent = await response.text();
          setUserMultipleIconSvg(fileContent);
        }
        
        // Иконка инфраструктуры (dish-washer)
        const dishWasherAsset = Asset.fromModule(require('../../assets/images/dish-washer-icon.svg'));
        await dishWasherAsset.downloadAsync();
        if (dishWasherAsset.localUri) {
          const response = await fetch(dishWasherAsset.localUri);
          const fileContent = await response.text();
          setDishWasherIconSvg(fileContent);
        }
        
        // Иконка рисков (legal-document)
        const legalDocumentAsset = Asset.fromModule(require('../../assets/images/legal-document-icon.svg'));
        await legalDocumentAsset.downloadAsync();
        if (legalDocumentAsset.localUri) {
          const response = await fetch(legalDocumentAsset.localUri);
          const fileContent = await response.text();
          setLegalDocumentIconSvg(fileContent);
        }
        
        // Иконка стратегии (chart-increase)
        const chartIncreaseAsset = Asset.fromModule(require('../../assets/images/chart-increase-icon.svg'));
        await chartIncreaseAsset.downloadAsync();
        if (chartIncreaseAsset.localUri) {
          const response = await fetch(chartIncreaseAsset.localUri);
          const fileContent = await response.text();
          setChartIncreaseIconSvg(fileContent);
        }
      } catch (error) {
        console.error('Ошибка загрузки SVG иконок блоков:', error);
      }
    };
    
    loadEfficiencyIcons();
    loadBlockIcons();
  };

  // Обновляем блоки при возврате на экран (БЕЗ очистки данных)
  useFocusEffect(
    useCallback(() => {
      console.log('Экран блоков получил фокус, обновляем блоки...');
      loadBlocksWithoutClearing();
    }, [])
  );


  const mergeBlocksWithDefaults = (source: DiagnosisBlock[]): DiagnosisBlock[] =>
    DEFAULT_BLOCKS.map(defaultBlock => {
      const storedBlock = source.find(block => block.id === defaultBlock.id);
      return storedBlock ? { ...defaultBlock, ...storedBlock } : defaultBlock;
    });

  const persistBlocks = async (blocksToSave: DiagnosisBlock[]) => {
    try {
      await AsyncStorage.setItem('diagnosisBlocks', JSON.stringify(blocksToSave));
      const userId = await getCurrentUserId();
      if (userId) {
        await saveUserBlocks(userId, blocksToSave);
      }
    } catch (error) {
      console.error('Ошибка сохранения блоков:', error);
    }
  };

  const fetchBlocks = async (): Promise<DiagnosisBlock[]> => {
    let blocksSource: DiagnosisBlock[] = [];

    try {
      const userId = await getCurrentUserId();

      if (userId) {
        const userBlocks = await loadUserBlocks(userId);
        if (Array.isArray(userBlocks) && userBlocks.length) {
          blocksSource = userBlocks;
        }
      }

      if (!blocksSource.length) {
        const storedBlocks = await AsyncStorage.getItem('diagnosisBlocks');
        if (storedBlocks) {
          blocksSource = JSON.parse(storedBlocks);
        }
      }
    } catch (error) {
      console.error('Ошибка получения блоков:', error);
    }

    if (!blocksSource.length) {
      return DEFAULT_BLOCKS;
    }

    return mergeBlocksWithDefaults(blocksSource);
  };

  const loadBlocksWithoutClearing = async () => {
    try {
      console.log('Загружаем блоки без очистки...');
      const allBlocks = await fetchBlocks();
      setBlocks(allBlocks);
      await persistBlocks(allBlocks);
      console.log('Блоки обновлены в состоянии:', allBlocks.length);
    } catch (error) {
      console.error('Ошибка загрузки блоков:', error);
    }
  };


  // Принудительная инициализация блоков, если они пустые
  useEffect(() => {
    if (!loading && blocks.length === 0) {
      setBlocks(DEFAULT_BLOCKS);
    }
  }, [loading, blocks.length]);

  const loadBlocks = async () => {
    try {
      console.log('Загружаем блоки диагностики...');
      const allBlocks = await fetchBlocks();
      setBlocks(allBlocks);
      await persistBlocks(allBlocks);
      console.log('Блоки загружены и сохранены');
    } catch (error) {
      console.error('Ошибка загрузки блоков:', error);
      // В случае ошибки показываем блоки по умолчанию
      setBlocks(DEFAULT_BLOCKS);
    } finally {
      setLoading(false);
    }
  };
  const handleBlockPress = (block: DiagnosisBlock) => {
    console.log('Нажата карточка блока:', block.title);
    // Переходим сразу к вопросам блока
    navigation.navigate('BlockQuestions', { blockId: block.id, blockTitle: block.title });
  };

  // Функция для получения SVG иконки блока
  const getBlockIconSvg = (blockId: string): string | null => {
    const iconMap: Record<string, string | null> = {
      'concept': colorsIconSvg,
      'finance': coinsIconSvg,
      'management': chartBarLineIconSvg,
      'menu': fileIconSvg,
      'marketing': marketingIconSvg,
      'operations': computerSettingsIconSvg,
      'client_experience': userMultipleIconSvg,
      'infrastructure': dishWasherIconSvg,
      'risks': legalDocumentIconSvg,
      'strategy': chartIncreaseIconSvg,
    };
    return iconMap[blockId] || null;
  };

  // Функция для получения цветов badge эффективности (как на дашборде)
  const getDiagnosisBadgeColors = (value: number) => {
    if (value === 0 || value === undefined || value === null) {
      return { bg: '#F6F8FA', text: '#525866' }; // серый
    }
    if (value >= 78) return { bg: '#CBF5E5', text: '#176448' }; // зеленый
    if (value >= 38) return { bg: '#FFDAC2', text: '#6E330C' }; // оранжевый (для 38-77)
    return { bg: '#F8C9D2', text: '#710E21' }; // красный (для < 38)
  };

  // Функция для подсчета количества вопросов в блоке
  const getQuestionCountForBlock = (blockId: string): number => {
    const blockData = (questionsData as any[]).find((block: any) => block.id === blockId);
    return blockData?.questions?.length || 0;
  };

  const getEfficiencyColor = (efficiency?: number): { bg: string; text: string; border?: string } => {
    if (efficiency === undefined || efficiency === null) {
      return { bg: palette.gray200, text: palette.gray500 };
    }

    if (efficiency >= 80) {
      return { bg: '#E6F7F1', text: palette.success, border: '#81C784' };
    } else if (efficiency >= 60) {
      return { bg: '#E5EBFF', text: palette.primaryBlue, border: '#A7B5FF' };
    } else if (efficiency >= 40) {
      return { bg: '#FFF4E6', text: palette.primaryOrange, border: '#FFBE7B' };
    } else {
      return { bg: '#FFE9EC', text: palette.error, border: '#FF9AA4' };
    }
  };

  const renderBlock = ({ item }: { item: DiagnosisBlock }) => {
    const colors = getEfficiencyColor(item.efficiency);
    
    return (
      <AnimatedPressable
        style={[
          styles.blockCard,
          { 
            backgroundColor: palette.white,
            borderColor: item.completed ? (colors.border || colors.text) : palette.gray200,
            borderLeftWidth: item.completed ? 6 : 1,
            borderLeftColor: colors.border || palette.gray300
          }
        ]}
        onPress={() => handleBlockPress(item)}
      >
        <View style={styles.blockHeader}>
          <Text style={styles.blockTitle}>{item.title}</Text>
          {item.completed && (
            <Ionicons name="checkmark-circle" size={22} color={palette.primaryOrange} />
          )}
        </View>
        <Text style={styles.blockDescription}>{item.description}</Text>
        {item.completed && item.efficiency !== undefined ? (
          <View style={styles.efficiencyContainer}>
            <Text style={[styles.efficiencyValue, { color: colors.text }]}>
              {item.efficiency}%
            </Text>
            <Text style={[styles.efficiencyLabel, { color: colors.text }]}>эффективность</Text>
          </View>
        ) : (
          <View style={styles.efficiencyContainer}>
            <Text style={[styles.efficiencyValue, { color: palette.gray500 }]}>—</Text>
            <Text style={[styles.efficiencyLabel, { color: palette.gray500 }]}>не пройдено</Text>
          </View>
        )}
      </AnimatedPressable>
    );
  };

  const completedCount = blocks.filter(block => block.completed).length;

  return (
    <View style={styles.container}>
      <ScrollView 
        ref={scrollViewRef}
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        onScroll={(event) => {
          const offsetY = event.nativeEvent.contentOffset.y;
          // Обработка скролла
        }}
        scrollEventThrottle={16}
      >
      {/* Секция профиля проекта */}
      <View style={[styles.section, styles.profileSection]}>
        <View style={styles.profileInfo}>
          {/* Аватар компании */}
          <View style={styles.avatarContainer}>
            {projectAvatarUri ? (
              <Image source={{ uri: projectAvatarUri }} style={styles.avatarImage} />
            ) : (
              <View style={styles.avatarPlaceholder}>
                <Ionicons name="business" size={32} color={palette.gray400} />
              </View>
            )}
          </View>
          
          {/* Название и город */}
          <View style={styles.projectInfo}>
            <Text style={styles.projectName}>Проект</Text>
            <View style={styles.cityContainer}>
              <Text style={styles.cityText}>{city || 'город'}</Text>
              <View style={styles.cityIconContainer}>
                {cityIconSvg ? (
                  <SvgXml xml={cityIconSvg} width={16} height={16} />
                ) : (
                  <View style={{ width: 16, height: 16 }} />
                )}
              </View>
            </View>
          </View>
        </View>
        
        {/* Кнопка Помощь PELBY */}
        <AnimatedPressable 
          style={styles.helpButton}
          onPress={() => {
            if (navigation) {
              navigation.navigate('Help');
            }
          }}
        >
          <View style={styles.helpButtonIconContainer}>
            {helpButtonIconSvg ? (
              <SvgXml xml={helpButtonIconSvg} width={18} height={18} />
            ) : (
              <View style={{ width: 18, height: 18 }} />
            )}
          </View>
          <Text style={styles.helpButtonText}>Помощь PELBY</Text>
        </AnimatedPressable>
      </View>

      {/* Секция с иконками часов и плюсика */}
      <View style={[styles.section, styles.efficiencySection]}>
        <View style={styles.efficiencyHeader}>
          <View style={styles.efficiencyTitleContainer}>
            <Text style={styles.efficiencyTitle}>Диагностика</Text>
          </View>
          <View style={styles.efficiencyIcons}>
            {refreshIconSvg && (
              <AnimatedPressable style={styles.iconButton}>
                <SvgXml xml={refreshIconSvg} width={38} height={38} />
              </AnimatedPressable>
            )}
            {addIconSvg && (
              <AnimatedPressable style={styles.iconButton}>
                <SvgXml xml={addIconSvg} width={38} height={38} />
              </AnimatedPressable>
            )}
          </View>
        </View>
      </View>

      {/* Секции-табы */}
      <View style={styles.tabsContainer}>
        <ScrollView 
          horizontal 
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.tabsScrollContent}
        >
          <TouchableOpacity 
            style={[
              styles.tabButton,
              activeTab === 'Все' && styles.tabButtonActive
            ]}
            onPress={() => setActiveTab('Все')}
          >
            <Text style={[
              styles.tabButtonText,
              activeTab === 'Все' && styles.tabButtonTextActive
            ]}>
              Все
            </Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={[
              styles.tabButton,
              activeTab === 'К прохождению' && styles.tabButtonActive
            ]}
            onPress={() => setActiveTab('К прохождению')}
          >
            <Text style={[
              styles.tabButtonText,
              activeTab === 'К прохождению' && styles.tabButtonTextActive
            ]}>
              К прохождению
            </Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={[
              styles.tabButton,
              activeTab === 'Начатые' && styles.tabButtonActive
            ]}
            onPress={() => setActiveTab('Начатые')}
          >
            <Text style={[
              styles.tabButtonText,
              activeTab === 'Начатые' && styles.tabButtonTextActive
            ]}>
              Начатые
            </Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={[
              styles.tabButton,
              activeTab === 'Завершенные' && styles.tabButtonActive
            ]}
            onPress={() => setActiveTab('Завершенные')}
          >
            <Text style={[
              styles.tabButtonText,
              activeTab === 'Завершенные' && styles.tabButtonTextActive
            ]}>
              Завершенные
            </Text>
          </TouchableOpacity>
        </ScrollView>
      </View>

      {/* Серая линия под табами */}
      <View style={styles.tabsDivider} />

      {/* Заголовок "К прохождению" и блоки */}
      {(activeTab === 'Все' || activeTab === 'К прохождению') && (
      <View style={styles.toPassSection}>
        <Text style={styles.toPassTitle}>К прохождению</Text>
        <View style={styles.toPassBlocksContainer}>
          {/* Блок "Финансы и бухгалтерия" */}
          <TouchableOpacity 
            style={styles.toPassBlockCard}
            onPress={() => navigation.navigate('BlockQuestions', { blockId: 'finance', blockTitle: 'Финансы и бухгалтерия' })}
            activeOpacity={0.7}
          >
            <View style={styles.toPassBlockTopRow}>
              <View style={styles.toPassBlockIconCircle}>
                <View style={styles.toPassBlockIconScaled}>
                  {coinsIconSvg ? (
                    <SvgXml xml={coinsIconSvg} width={38} height={38} />
                  ) : (
                    <Ionicons name="cube-outline" size={38} color={palette.primaryBlue} />
                  )}
                </View>
              </View>
              <View style={styles.toPassBlockTextContainer}>
                <Text style={styles.toPassBlockTitle}>Финансы и бухгалтерия</Text>
                <Text style={styles.toPassBlockSubtitle}>{getQuestionCountForBlock('finance')} вопросов</Text>
              </View>
              {arrowRightIconSvg && (
                <View style={styles.toPassBlockArrow}>
                  <SvgXml xml={arrowRightIconSvg} width={24} height={24} />
                </View>
              )}
            </View>
          </TouchableOpacity>

          {/* Блок "Концепция и позиционирование" */}
          <TouchableOpacity 
            style={styles.toPassBlockCard}
            onPress={() => navigation.navigate('BlockQuestions', { blockId: 'concept', blockTitle: 'Концепция и позиционирование' })}
            activeOpacity={0.7}
          >
            <View style={styles.toPassBlockTopRow}>
              <View style={styles.toPassBlockIconCircle}>
                <View style={styles.toPassBlockIconScaled}>
                  {colorsIconSvg ? (
                    <SvgXml xml={colorsIconSvg} width={38} height={38} />
                  ) : (
                    <Ionicons name="cube-outline" size={38} color={palette.primaryBlue} />
                  )}
                </View>
              </View>
              <View style={styles.toPassBlockTextContainer}>
                <Text style={styles.toPassBlockTitle}>Концепция и позиционирование</Text>
                <Text style={styles.toPassBlockSubtitle}>{getQuestionCountForBlock('concept')} вопросов</Text>
              </View>
              {arrowRightIconSvg && (
                <View style={styles.toPassBlockArrow}>
                  <SvgXml xml={arrowRightIconSvg} width={24} height={24} />
                </View>
              )}
            </View>
          </TouchableOpacity>
        </View>
      </View>
      )}

      {/* Серая линия под блоком "Концепция и позиционирование" */}
      {(activeTab === 'Все' || activeTab === 'К прохождению') && (
      <View style={styles.blocksDivider} />
      )}

      {/* Заголовок "В процессе" */}
      {(activeTab === 'Все' || activeTab === 'Начатые') && (
      <View style={styles.inProgressSection}>
          <Text style={styles.inProgressTitle}>В процессе</Text>
          <View style={styles.inProgressBlocksContainer}>
            {/* Блок "Управление и организация" */}
            <TouchableOpacity 
              style={styles.inProgressBlockCard}
              onPress={() => navigation.navigate('BlockQuestions', { blockId: 'management', blockTitle: 'Управление и организация' })}
              activeOpacity={0.7}
            >
              <View style={styles.inProgressBlockTopRow}>
                <View style={styles.inProgressBlockIconCircle}>
                  <View style={styles.inProgressBlockIconScaled}>
                    {chartBarLineIconSvg ? (
                      <SvgXml xml={chartBarLineIconSvg} width={38} height={38} />
                    ) : (
                      <Ionicons name="cube-outline" size={38} color={palette.primaryBlue} />
                    )}
                  </View>
                </View>
                <View style={styles.inProgressBlockTextContainer}>
                  <Text style={styles.inProgressBlockTitle}>Управление и организация</Text>
                  <Text style={styles.inProgressBlockSubtitle}>осталось 4 вопроса</Text>
                </View>
                {arrowRightIconSvg && (
                  <View style={styles.inProgressBlockArrow}>
                    <SvgXml xml={arrowRightIconSvg} width={24} height={24} />
                  </View>
                )}
              </View>
            </TouchableOpacity>
          </View>
        </View>
      )}

      {/* Серая линия под блоком "Управление и организация" */}
      {(activeTab === 'Все' || activeTab === 'Начатые') && (
      <View style={styles.blocksDivider} />
      )}

      {/* Заголовок "Завершенные блоки" */}
      {(activeTab === 'Все' || activeTab === 'Завершенные') && (
      <View style={styles.completedSection}>
        <View style={styles.completedHeader}>
          <Text style={styles.completedTitle}>Завершенные блоки</Text>
          <Text style={styles.completedCount}>7/10</Text>
        </View>
        <View style={styles.completedBlocksContainer}>
          {/* Блок "Продуктовая стратегия" */}
          <TouchableOpacity 
            style={styles.completedBlockCard}
            onPress={() => navigation.navigate('BlockQuestions', { blockId: 'menu', blockTitle: 'Продуктовая стратегия' })}
            activeOpacity={0.7}
          >
            <View style={styles.completedBlockTopRow}>
              <View style={styles.completedBlockIconCircle}>
                <View style={styles.completedBlockIconScaled}>
                  {fileIconSvg ? (
                    <SvgXml xml={fileIconSvg} width={38} height={38} />
                  ) : (
                    <Ionicons name="cube-outline" size={38} color={palette.primaryBlue} />
                  )}
                </View>
              </View>
              <View style={styles.completedBlockTextContainer}>
                <Text style={styles.completedBlockTitle}>Продуктовая стратегия</Text>
                <Text style={styles.completedBlockSubtitle}>{getQuestionCountForBlock('menu')} вопросов</Text>
              </View>
              {(() => {
                const efficiency = 85; // Пример эффективности
                const badgeColors = getDiagnosisBadgeColors(efficiency);
                return (
                  <View style={[styles.completedBlockEfficiencyBadge, { backgroundColor: badgeColors.bg }]}>
                    <Text style={[styles.completedBlockEfficiencyPercent, { color: badgeColors.text }]}>
                      {efficiency}%
                    </Text>
                  </View>
                );
              })()}
            </View>
          </TouchableOpacity>

          {/* Блок "Маркетинг и продажи" */}
          <TouchableOpacity 
            style={styles.completedBlockCard}
            onPress={() => navigation.navigate('BlockQuestions', { blockId: 'marketing', blockTitle: 'Маркетинг и продажи' })}
            activeOpacity={0.7}
          >
            <View style={styles.completedBlockTopRow}>
              <View style={styles.completedBlockIconCircle}>
                <View style={styles.completedBlockIconScaled}>
                  {marketingIconSvg ? (
                    <SvgXml xml={marketingIconSvg} width={38} height={38} />
                  ) : (
                    <Ionicons name="cube-outline" size={38} color={palette.primaryBlue} />
                  )}
                </View>
              </View>
              <View style={styles.completedBlockTextContainer}>
                <Text style={styles.completedBlockTitle}>Маркетинг и продажи</Text>
                <Text style={styles.completedBlockSubtitle}>{getQuestionCountForBlock('marketing')} вопросов</Text>
              </View>
              {(() => {
                const efficiency = 72; // Пример эффективности
                const badgeColors = getDiagnosisBadgeColors(efficiency);
                return (
                  <View style={[styles.completedBlockEfficiencyBadge, { backgroundColor: badgeColors.bg }]}>
                    <Text style={[styles.completedBlockEfficiencyPercent, { color: badgeColors.text }]}>
                      {efficiency}%
                    </Text>
                  </View>
                );
              })()}
            </View>
          </TouchableOpacity>

          {/* Блок "Операционная деятельность" */}
          <TouchableOpacity 
            style={styles.completedBlockCard}
            onPress={() => navigation.navigate('BlockQuestions', { blockId: 'operations', blockTitle: 'Операционная деятельность' })}
            activeOpacity={0.7}
          >
            <View style={styles.completedBlockTopRow}>
              <View style={styles.completedBlockIconCircle}>
                <View style={styles.completedBlockIconScaled}>
                  {computerSettingsIconSvg ? (
                    <SvgXml xml={computerSettingsIconSvg} width={38} height={38} />
                  ) : (
                    <Ionicons name="cube-outline" size={38} color={palette.primaryBlue} />
                  )}
                </View>
              </View>
              <View style={styles.completedBlockTextContainer}>
                <Text style={styles.completedBlockTitle}>Операционная деятельность</Text>
                <Text style={styles.completedBlockSubtitle}>{getQuestionCountForBlock('operations')} вопросов</Text>
              </View>
              {(() => {
                const efficiency = 45; // Пример эффективности
                const badgeColors = getDiagnosisBadgeColors(efficiency);
                return (
                  <View style={[styles.completedBlockEfficiencyBadge, { backgroundColor: badgeColors.bg }]}>
                    <Text style={[styles.completedBlockEfficiencyPercent, { color: badgeColors.text }]}>
                      {efficiency}%
                    </Text>
                  </View>
                );
              })()}
            </View>
          </TouchableOpacity>

          {/* Блок "Клиентский опыт" */}
          <TouchableOpacity 
            style={styles.completedBlockCard}
            onPress={() => navigation.navigate('BlockQuestions', { blockId: 'client_experience', blockTitle: 'Клиентский опыт' })}
            activeOpacity={0.7}
          >
            <View style={styles.completedBlockTopRow}>
              <View style={styles.completedBlockIconCircle}>
                <View style={styles.completedBlockIconScaled}>
                  {userMultipleIconSvg ? (
                    <SvgXml xml={userMultipleIconSvg} width={38} height={38} />
                  ) : (
                    <Ionicons name="cube-outline" size={38} color={palette.primaryBlue} />
                  )}
                </View>
              </View>
              <View style={styles.completedBlockTextContainer}>
                <Text style={styles.completedBlockTitle}>Клиентский опыт</Text>
                <Text style={styles.completedBlockSubtitle}>{getQuestionCountForBlock('client_experience')} вопросов</Text>
              </View>
              {(() => {
                const efficiency = 92; // Пример эффективности
                const badgeColors = getDiagnosisBadgeColors(efficiency);
                return (
                  <View style={[styles.completedBlockEfficiencyBadge, { backgroundColor: badgeColors.bg }]}>
                    <Text style={[styles.completedBlockEfficiencyPercent, { color: badgeColors.text }]}>
                      {efficiency}%
                    </Text>
                  </View>
                );
              })()}
            </View>
          </TouchableOpacity>

          {/* Блок "Инфраструктура и оборудование" */}
          <TouchableOpacity 
            style={styles.completedBlockCard}
            onPress={() => navigation.navigate('BlockQuestions', { blockId: 'infrastructure', blockTitle: 'Инфраструктура и оборудование' })}
            activeOpacity={0.7}
          >
            <View style={styles.completedBlockTopRow}>
              <View style={styles.completedBlockIconCircle}>
                <View style={styles.completedBlockIconScaled}>
                  {dishWasherIconSvg ? (
                    <SvgXml xml={dishWasherIconSvg} width={38} height={38} />
                  ) : (
                    <Ionicons name="cube-outline" size={38} color={palette.primaryBlue} />
                  )}
                </View>
              </View>
              <View style={styles.completedBlockTextContainer}>
                <Text style={styles.completedBlockTitle}>Инфраструктура и оборудование</Text>
                <Text style={styles.completedBlockSubtitle}>{getQuestionCountForBlock('infrastructure')} вопросов</Text>
              </View>
              {(() => {
                const efficiency = 35; // Пример эффективности
                const badgeColors = getDiagnosisBadgeColors(efficiency);
                return (
                  <View style={[styles.completedBlockEfficiencyBadge, { backgroundColor: badgeColors.bg }]}>
                    <Text style={[styles.completedBlockEfficiencyPercent, { color: badgeColors.text }]}>
                      {efficiency}%
                    </Text>
                  </View>
                );
              })()}
            </View>
          </TouchableOpacity>

          {/* Блок "Риски и нормы" */}
          <TouchableOpacity 
            style={styles.completedBlockCard}
            onPress={() => navigation.navigate('BlockQuestions', { blockId: 'risks', blockTitle: 'Риски и нормы' })}
            activeOpacity={0.7}
          >
            <View style={styles.completedBlockTopRow}>
              <View style={styles.completedBlockIconCircle}>
                <View style={styles.completedBlockIconScaled}>
                  {legalDocumentIconSvg ? (
                    <SvgXml xml={legalDocumentIconSvg} width={38} height={38} />
                  ) : (
                    <Ionicons name="cube-outline" size={38} color={palette.primaryBlue} />
                  )}
                </View>
              </View>
              <View style={styles.completedBlockTextContainer}>
                <Text style={styles.completedBlockTitle}>Риски и нормы</Text>
                <Text style={styles.completedBlockSubtitle}>{getQuestionCountForBlock('risks')} вопросов</Text>
              </View>
              {(() => {
                const efficiency = 65; // Пример эффективности
                const badgeColors = getDiagnosisBadgeColors(efficiency);
                return (
                  <View style={[styles.completedBlockEfficiencyBadge, { backgroundColor: badgeColors.bg }]}>
                    <Text style={[styles.completedBlockEfficiencyPercent, { color: badgeColors.text }]}>
                      {efficiency}%
                    </Text>
                  </View>
                );
              })()}
            </View>
          </TouchableOpacity>

          {/* Блок "Стратегия развития" */}
          <TouchableOpacity 
            style={styles.completedBlockCard}
            onPress={() => navigation.navigate('BlockQuestions', { blockId: 'strategy', blockTitle: 'Стратегия развития' })}
            activeOpacity={0.7}
          >
            <View style={styles.completedBlockTopRow}>
              <View style={styles.completedBlockIconCircle}>
                <View style={styles.completedBlockIconScaled}>
                  {chartIncreaseIconSvg ? (
                    <SvgXml xml={chartIncreaseIconSvg} width={38} height={38} />
                  ) : (
                    <Ionicons name="cube-outline" size={38} color={palette.primaryBlue} />
                  )}
                </View>
              </View>
              <View style={styles.completedBlockTextContainer}>
                <Text style={styles.completedBlockTitle}>Стратегия развития</Text>
                <Text style={styles.completedBlockSubtitle}>{getQuestionCountForBlock('strategy')} вопросов</Text>
              </View>
              {(() => {
                const efficiency = 78; // Пример эффективности
                const badgeColors = getDiagnosisBadgeColors(efficiency);
                return (
                  <View style={[styles.completedBlockEfficiencyBadge, { backgroundColor: badgeColors.bg }]}>
                    <Text style={[styles.completedBlockEfficiencyPercent, { color: badgeColors.text }]}>
                      {efficiency}%
                    </Text>
                  </View>
                );
              })()}
            </View>
          </TouchableOpacity>
        </View>
      </View>
      )}

      {/* Серая линия под секцией "Завершенные блоки" */}
      {(activeTab === 'Все' || activeTab === 'Завершенные') && (
      <View style={styles.blocksDivider} />
      )}

      {/* Кнопки под серой линией */}
      <View style={styles.buttonsContainer}>
        <AnimatedPressable
          style={styles.continueButton}
          onPress={() => {
            // Обработчик нажатия
          }}
        >
          <Text style={styles.continueButtonText}>Продолжить диагностику</Text>
        </AnimatedPressable>

        <AnimatedPressable
          style={styles.secondButton}
          onPress={() => {
            // Обработчик нажатия
          }}
        >
          <Text style={styles.secondButtonText}>Новая диагностика</Text>
        </AnimatedPressable>
      </View>

      {/* Уведомление под кнопками */}
      <View style={styles.notificationContainer}>
        <View style={styles.notificationLeftBar} />
        <View style={styles.notificationContent}>
          <Text style={styles.notificationText}>
            Мы рекомендуем сначала{' '}
            <Text style={styles.notificationTextBold}>завершить оставшиеся блоки</Text>
            {' '}и выполнить задачи по улучшению.{'\n'}
            Повторную диагностику оптимально{' '}
            <Text style={styles.notificationTextBold}>проходить раз в месяц</Text>
            {' '}— так вы увидите динамику роста.
          </Text>
          <TouchableOpacity style={styles.notificationButton}>
            <Text style={styles.notificationButtonText}>Настроить уведомления</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Отступ после уведомления */}
      <View style={{ height: 30 }} />

      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: palette.background,
  },
  scrollView: {
    flex: 1,
  },
  scrollViewContent: {
    paddingBottom: spacing.xxl,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: palette.background,
  },
  loadingText: {
    fontSize: 16,
    color: palette.primaryBlue,
  },
  header: {
    paddingHorizontal: spacing.md,
    paddingTop: spacing.xxl,
    paddingBottom: spacing.md,
    backgroundColor: palette.background,
    marginBottom: spacing.sm,
  },
  headerTop: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 60,
    marginBottom: spacing.xs,
  },
  headerTitleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerLogo: {
    width: 28,
    height: 28,
    marginRight: spacing.sm,
  },
  headerTitle: {
    ...typography.heading2,
    color: palette.primaryBlue,
  },
  startButtonContainer: {
    position: 'relative',
    marginTop: spacing.xs,
  },
  progress: {
    fontSize: 14,
    color: palette.primaryOrange,
    fontWeight: '600',
    textAlign: 'right',
    marginTop: spacing.sm,
    paddingRight: spacing.xs,
  },
  emptyText: {
    fontSize: 16,
    color: palette.gray600,
    textAlign: 'center',
    marginTop: spacing.lg,
  },
  listContainer: {
    paddingHorizontal: spacing.md,
    paddingBottom: spacing.xxl,
  },
  blockCard: {
    backgroundColor: palette.white,
    padding: spacing.md,
    borderRadius: radii.lg,
    marginBottom: spacing.md,
    borderWidth: 1,
    borderColor: palette.gray200,
    shadowColor: palette.midnightBlue,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.05,
    shadowRadius: 16,
    elevation: 4,
    minHeight: 120,
  },
  blockHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  blockTitle: {
    ...typography.heading3,
    color: palette.primaryBlue,
    flex: 1,
  },
  blockDescription: {
    fontSize: 14,
    color: palette.gray600,
    lineHeight: 20,
    marginBottom: spacing.sm,
  },
  efficiencyContainer: {
    alignItems: 'center',
    marginTop: spacing.xs,
  },
  efficiencyValue: {
    fontSize: 26,
    fontWeight: '700',
    marginBottom: spacing.xs,
  },
  efficiencyLabel: {
    fontSize: 11,
    fontWeight: '500',
    textTransform: 'uppercase',
    color: palette.gray600,
    letterSpacing: 0.5,
  },
  section: {
    marginHorizontal: spacing.md,
    marginBottom: spacing.md,
  },
  // Секция профиля проекта
  profileSection: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingRight: 0,
    paddingVertical: spacing.md,
    marginTop: spacing.xxl,
    marginBottom: spacing.lg,
    marginRight: spacing.md,
    marginLeft: spacing.sm,
  },
  profileInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    transform: [{ translateY: -2 }],
  },
  avatarContainer: {
    marginRight: 2,
  },
  avatarImage: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: palette.gray100,
  },
  avatarPlaceholder: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: palette.gray100,
    justifyContent: 'center',
    alignItems: 'center',
  },
  projectInfo: {
    flex: 1,
    transform: [{ translateY: -2 }],
  },
  projectName: {
    fontSize: 18,
    fontWeight: '400',
    color: '#0A0D14',
    marginBottom: spacing.xxs,
    marginTop: 0,
    marginLeft: -1,
    transform: [{ translateY: 2 }],
    ...(Platform.OS === 'android' && { includeFontPadding: false }),
    minHeight: 22, // Фиксируем высоту, чтобы не прыгало
    minWidth: 60, // Фиксируем ширину, чтобы не прыгало
  },
  cityContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    minHeight: 18, // Фиксируем высоту, чтобы не прыгало
  },
  cityText: {
    fontSize: 14,
    color: palette.gray600,
    marginRight: 2,
    minHeight: 16, // Фиксируем высоту, чтобы не прыгало
    minWidth: 40, // Фиксируем ширину, чтобы не прыгало
  },
  cityIconContainer: {
    marginLeft: 2,
    transform: [{ translateY: 1 }],
    width: 16,
    height: 16,
    justifyContent: 'center',
    alignItems: 'center',
  },
  helpButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FD680A',
    paddingLeft: 6,
    paddingRight: 6,
    paddingVertical: 6,
    height: 32,
    borderRadius: 999,
    marginLeft: -1,
    transform: [{ translateY: -2 }],
  },
  helpButtonIconContainer: {
    marginRight: 2,
    marginLeft: 0,
    width: 18,
    height: 18,
    justifyContent: 'center',
    alignItems: 'center',
  },
  helpButtonText: {
    fontSize: 14,
    fontWeight: '300',
    color: palette.white,
    lineHeight: 16,
    transform: [{ translateY: 0 }, { translateX: -1 }],
    ...(Platform.OS === 'android' && { includeFontPadding: false }),
    minHeight: 16, // Фиксируем высоту, чтобы не прыгало
    minWidth: 90, // Фиксируем ширину текста, чтобы не прыгало
  },
  efficiencySection: {
    marginLeft: spacing.sm,
    marginRight: spacing.md,
    marginBottom: 0, // Убираем отступ снизу, чтобы контролировать расстояние до табов
  },
  efficiencyHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: spacing.md - 48, // Опущено на 2 пикселя (было -50, стало -48)
    marginBottom: spacing.sm,
  },
  efficiencyTitleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  efficiencyTitle: {
    fontSize: 27,
    fontWeight: '400',
    color: '#0A0D14',
    marginLeft: 5,
  },
  efficiencyIcons: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
  },
  iconButton: {
    // Убрали padding, чтобы иконки выравнивались как метрики ниже
  },
  tabsContainer: {
    marginTop: spacing.lg - spacing.sm - 2, // Поднято на 2 пикселя вверх
    marginBottom: spacing.md,
  },
  tabsScrollContent: {
    paddingLeft: spacing.sm + 5, // Выравнивание по левому краю заголовка "Диагностика"
    paddingRight: spacing.sm,
    gap: spacing.xxs,
  },
  tabButton: {
    paddingHorizontal: spacing.md - 2,
    paddingVertical: spacing.xs,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#E2E4E9',
    marginRight: spacing.xxs,
  },
  tabButtonActive: {
    backgroundColor: '#191BDF',
    borderColor: '#191BDF',
  },
  tabButtonText: {
    fontSize: 16,
    fontWeight: '400',
    color: '#525866',
  },
  tabButtonTextActive: {
    color: '#FFFFFF',
  },
  tabsDivider: {
    height: 1,
    backgroundColor: '#E2E4E9',
    marginLeft: spacing.sm + 5, // Выравнивание по левому краю табов
    marginRight: spacing.sm,
    marginTop: spacing.md, // Такой же отступ как у заголовка "К прохождению"
    marginBottom: 0,
    zIndex: 1,
    position: 'relative',
  },
  toPassSection: {
    marginTop: spacing.lg,
    marginLeft: spacing.md,
    marginRight: spacing.md,
  },
  toPassTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#0A0D14',
    fontFamily: 'Manrope-SemiBold',
    marginBottom: spacing.md,
  },
  toPassBlocksContainer: {
    gap: 15,
  },
  toPassBlockCard: {
    width: cardWidth,
    height: 100,
    backgroundColor: palette.white,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#E2E4E9',
    padding: spacing.md,
  },
  toPassBlockTopRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    height: '100%',
  },
  toPassBlockIconCircle: {
    width: 50,
    height: 50,
    borderRadius: 25,
    borderWidth: 1,
    borderColor: '#E2E4E9',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'transparent',
    marginRight: spacing.sm,
  },
  toPassBlockIconScaled: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
    transform: [{ scale: 0.65 }],
  },
  toPassBlockTextContainer: {
    flex: 1,
  },
  toPassBlockTitle: {
    fontSize: 16,
    fontWeight: '500',
    color: '#0A0D14',
    fontFamily: 'Manrope-Medium',
    marginBottom: spacing.xxs,
  },
  toPassBlockSubtitle: {
    fontSize: 14,
    fontWeight: '300',
    color: palette.gray600,
    fontFamily: 'Manrope-Light',
  },
  toPassBlockArrow: {
    marginLeft: spacing.sm,
    alignSelf: 'center',
  },
  blocksDivider: {
    height: 1,
    backgroundColor: '#E2E4E9',
    marginLeft: spacing.md, // Такие же отступы как у блоков (toPassSection)
    marginRight: spacing.md,
    marginTop: spacing.lg + 15, // Увеличен отступ сверху еще на 5px
    marginBottom: 0,
    zIndex: 1,
    position: 'relative',
  },
  inProgressSection: {
    marginTop: spacing.md, // Такой же отступ как между табами и линией
    marginLeft: spacing.md, // Выравнивание по левой стороне как у toPassSection
    marginRight: spacing.md,
  },
  inProgressTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#0A0D14',
    fontFamily: 'Manrope-SemiBold',
    marginBottom: spacing.md,
  },
  inProgressBlocksContainer: {
    gap: 15,
  },
  inProgressBlockCard: {
    width: cardWidth,
    height: 100,
    backgroundColor: palette.white,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#E2E4E9',
    padding: spacing.md,
  },
  inProgressBlockTopRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    height: '100%',
  },
  inProgressBlockIconCircle: {
    width: 50,
    height: 50,
    borderRadius: 25,
    borderWidth: 1,
    borderColor: '#E2E4E9',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'transparent',
    marginRight: spacing.sm,
  },
  inProgressBlockIconScaled: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
    transform: [{ scale: 0.65 }],
  },
  inProgressBlockTextContainer: {
    flex: 1,
  },
  inProgressBlockTitle: {
    fontSize: 16,
    fontWeight: '500',
    color: '#0A0D14',
    fontFamily: 'Manrope-Medium',
    marginBottom: spacing.xxs,
  },
  inProgressBlockSubtitle: {
    fontSize: 14,
    fontWeight: '500',
    color: '#F17B2C',
    fontFamily: 'Manrope-Medium', // Увеличено на 100 (400 -> 500)
  },
  inProgressBlockArrow: {
    marginLeft: spacing.sm,
    alignSelf: 'center',
  },
  // Стили для секции "Завершенные блоки"
  completedSection: {
    marginTop: spacing.md,
    marginLeft: spacing.md,
    marginRight: spacing.md,
  },
  completedHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.md,
  },
  completedTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#0A0D14',
    fontFamily: 'Manrope-SemiBold',
  },
  completedCount: {
    fontSize: 16,
    fontWeight: '500',
    color: '#525866',
    fontFamily: 'Manrope-Medium', // Увеличено на 100 (400 -> 500)
  },
  completedBlocksContainer: {
    gap: 15, // Такой же отступ как между блоками в секции "К прохождению"
  },
  completedBlockCard: {
    width: cardWidth,
    height: 100,
    backgroundColor: palette.white,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#E2E4E9',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
  },
  completedBlockTopRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    height: '100%',
  },
  completedBlockIconCircle: {
    width: 50,
    height: 50,
    borderRadius: 25,
    borderWidth: 1,
    borderColor: '#E2E4E9',
    backgroundColor: '#F6F8FA',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: spacing.sm,
  },
  completedBlockIconScaled: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
    transform: [{ scale: 0.65 }],
  },
  completedBlockTextContainer: {
    flex: 1,
  },
  completedBlockTitle: {
    fontSize: 16,
    fontWeight: '500',
    color: '#0A0D14',
    fontFamily: 'Manrope-Medium',
    marginBottom: spacing.xxs,
  },
  completedBlockSubtitle: {
    fontSize: 14,
    fontWeight: '400',
    color: palette.gray600,
    fontFamily: 'Manrope-Regular',
  },
  completedBlockEfficiencyBadge: {
    borderRadius: 99,
    paddingHorizontal: 6,
    paddingVertical: 6,
    minWidth: 55,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: spacing.sm,
  },
  completedBlockEfficiencyPercent: {
    fontSize: 13,
    fontWeight: '600',
    lineHeight: 16,
    includeFontPadding: false,
  },
  // Стили для кнопок под серой линией
  buttonsContainer: {
    marginTop: 15, // Отступ от серой линии
    marginLeft: spacing.md,
    marginRight: spacing.md,
    marginBottom: 5, // Уменьшено на 10px (15 -> 5)
    gap: 15, // Отступ между кнопками (такой же как между блоками)
  },
  continueButton: {
    backgroundColor: '#191BDF',
    height: 61, // Увеличено на 5px (56 -> 61)
    paddingHorizontal: spacing.lg,
    borderRadius: 99,
    alignItems: 'center',
    justifyContent: 'center',
  },
  continueButtonText: {
    fontSize: 18,
    fontWeight: '600', // Увеличено на 100 (500 -> 600)
    fontFamily: Platform.select({
      ios: 'Manrope',
      android: 'Manrope',
      web: "'Manrope', sans-serif",
      default: 'Manrope',
    }),
    color: '#EBF1FF',
    textAlign: 'center',
  },
  secondButton: {
    backgroundColor: 'rgba(55, 93, 251, 0.1)', // #375DFB с непрозрачностью 10%
    height: 61, // Увеличено на 5px (56 -> 61)
    paddingHorizontal: spacing.lg,
    borderRadius: 99,
    alignItems: 'center',
    justifyContent: 'center',
  },
  secondButtonText: {
    fontSize: 18,
    fontWeight: '600', // Увеличено на 100 (500 -> 600)
    fontFamily: Platform.select({
      ios: 'Manrope',
      android: 'Manrope',
      web: "'Manrope', sans-serif",
      default: 'Manrope',
    }),
    color: '#162664',
    textAlign: 'center',
  },
  // Стили для уведомления
  notificationContainer: {
    flexDirection: 'row',
    marginTop: 15, // Такой же отступ как между блоками
    marginLeft: spacing.md,
    marginRight: spacing.md,
    marginBottom: -7, // Уменьшено еще на 15px (8 - 15 = -7)
    borderTopRightRadius: 12,
    borderBottomRightRadius: 12,
    overflow: 'hidden',
    backgroundColor: '#FEF3EB',
  },
  notificationLeftBar: {
    width: 4,
    backgroundColor: '#FD680A',
  },
  notificationContent: {
    flex: 1,
    padding: spacing.md,
  },
  notificationText: {
    fontSize: 15, // Уменьшено на 1px (16 -> 15)
    fontWeight: '400',
    color: 'rgba(10, 13, 20, 0.9)', // #0A0D14 с непрозрачностью 90%
    fontFamily: 'Manrope-Regular',
    lineHeight: 20,
    marginBottom: spacing.md,
  },
  notificationTextBold: {
    fontWeight: '600',
    fontFamily: 'Manrope-SemiBold',
  },
  notificationButton: {
    backgroundColor: '#FEF3EB',
    borderWidth: 1,
    borderColor: '#FD680A',
    borderRadius: 99,
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'flex-start',
  },
  notificationButtonText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#FD680A',
    fontFamily: 'Manrope-Medium',
  },
});
