# Быстрый гайд по референс-дизайну

## 📋 Файлы документации
- `reference-design-analysis.md` - Полный анализ дизайна
- `reference-css-styles.css` - Готовые CSS стили
- `reference-html-examples.html` - Примеры HTML компонентов

## 🎨 Корпоративные цвета

| Название | Hex | RGB | Использование |
|----------|-----|-----|---------------|
| **White** | `#ffffff` | 255/255/255 | Основной текст, кнопки |
| **WhiteSmoke** | `#f0f0f0` | 240/240/240 | Фон карточек |
| **Pattens Blue** | `#cfe1ed` | 207/225/237 | Светлые акценты |
| **Spring Bud** | `#b6ff00` | 182/255/0 | CTA кнопки |
| **Medium Slate Blue** | `#7d51fe` | 125/81/254 | Основной акцент |
| **Midnight Express** | `#242834` | 36/40/52 | Фон страницы |

## 🔤 Типографика

### Шрифты
- **Urbanist** (600) - H1 заголовки (48px)
- **Lexend** (400) - H2/H3/H4 (40px/32px/24px)
- **Inter** (400/500) - Основной текст (16px), навигация (12px)

### Размеры заголовков
- H1: 48px / 600 / Urbanist
- H2: 40px / 400 / Lexend
- H3: 32px или 24px / 400 / Lexend
- H4: 24px / 400 / Lexend
- Body: 16px / 400 / Inter
- Small: 14px / 400 / Inter
- Nav: 12px / 400 / Inter

## 🎯 Ключевые компоненты

### Кнопки
```css
/* Primary CTA */
.btn-primary {
  padding: 12px 24px;
  border-radius: 64px;
  height: 48px;
  font-size: 12px;
}

/* С корпоративным цветом */
.btn-cta {
  background: #b6ff00; /* Spring Bud */
  color: #242834; /* Midnight Express */
}
```

### Секции
```css
.section {
  padding: 80px 0;
}

.section-large {
  padding: 160px 0;
}
```

### Карточки
```css
.card {
  background: rgba(255, 255, 255, 0.05);
  border-radius: 20px;
  padding: 32px;
}
```

## 📐 Spacing

- **Большие секции:** 120-160px вертикальный padding
- **Средние секции:** 80px вертикальный padding
- **Кнопки:** 12px 24px
- **Навигация:** 8px 12px для ссылок
- **Карточки:** 32px внутренний padding

## 🎨 Градиент (Hero секция)

```css
background: radial-gradient(200% 184% at 50% 5%, 
  #242834 31.31%,      /* Midnight Express */
  #7d51fe 47.50%,      /* Medium Slate Blue */
  #cfe1ed 58.40%,      /* Pattens Blue */
  #ffffff 85.77%       /* White */
);
```

## 📱 Адаптивность

- Grid: `grid-template-columns: repeat(3, 1fr)` → `1fr` на мобильных
- Заголовки уменьшаются: H1 48px → 36px
- Секции: 160px → 80px padding на мобильных

## 🔗 Референс
**URL:** https://ego-prisma-tmpl.framer.website/

## 💡 Быстрый старт

1. Подключите CSS файл: `reference-css-styles.css`
2. Используйте классы из `reference-html-examples.html`
3. Замените цвета на корпоративные (уже в CSS переменных)
4. Адаптируйте контент под ваш проект

## 🎯 Основные паттерны

1. **Темная тема** - черный/темно-синий фон с белым текстом
2. **Большие отступы** - щедрые padding'и между секциями
3. **Скругленные кнопки** - border-radius 64px-100px
4. **Минималистичная навигация** - прозрачный фон, простые ссылки
5. **Градиенты** - радиальные градиенты для hero-секций
6. **Карточки** - полупрозрачные с hover-эффектами


