import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, StyleSheet, ScrollView, Platform, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Asset } from 'expo-asset';
import { SvgXml } from 'react-native-svg';
import AnimatedPressable from '../components/AnimatedPressable';
import { palette, spacing } from '../styles/theme';

interface RegisterScreen2Props {
  onContinue: () => void;
  onSkip?: () => void;
  onBack?: () => void;
}

export default function RegisterScreen2({ onContinue, onSkip, onBack }: RegisterScreen2Props) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [userIconSvg, setUserIconSvg] = useState<string>('');
  const [emailIconSvg, setEmailIconSvg] = useState<string>('');
  const [logoPlaceholderSvg, setLogoPlaceholderSvg] = useState<string>('');

  useEffect(() => {
    // Загружаем SVG иконку для поля "Названия заведения"
    const loadUserIcon = async () => {
      try {
        const iconAsset = Asset.fromModule(require('../../assets/images/venue-name-icon.svg'));
        await iconAsset.downloadAsync();
        if (iconAsset.localUri) {
          const response = await fetch(iconAsset.localUri);
          const fileContent = await response.text();
          setUserIconSvg(fileContent);
        }
      } catch (error) {
        console.error('Ошибка загрузки SVG иконки пользователя (экран 2):', error);
      }
    };

    // Загружаем SVG иконку для поля "Адрес заведения"
    const loadEmailIcon = async () => {
      try {
        const iconAsset = Asset.fromModule(require('../../assets/images/venue-address-icon.svg'));
        await iconAsset.downloadAsync();
        if (iconAsset.localUri) {
          const response = await fetch(iconAsset.localUri);
          const fileContent = await response.text();
          setEmailIconSvg(fileContent);
        }
      } catch (error) {
        console.error('Ошибка загрузки SVG иконки email (экран 2):', error);
      }
    };

    const loadLogoPlaceholderIcon = async () => {
      try {
        const iconAsset = Asset.fromModule(require('../../assets/images/restaurant-avatar-placeholder.svg'));
        await iconAsset.downloadAsync();
        if (iconAsset.localUri) {
          const response = await fetch(iconAsset.localUri);
          const fileContent = await response.text();
          setLogoPlaceholderSvg(fileContent);
        }
      } catch (error) {
        console.error('Ошибка загрузки SVG заглушки логотипа (экран 2):', error);
      }
    };

    loadUserIcon();
    loadEmailIcon();
    loadLogoPlaceholderIcon();
  }, []);

  return (
    <View style={styles.container}>
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <View>
          {/* Header: Back button, Step indicator and Skip button */}
          <View style={styles.header}>
            {onBack && (
              <TouchableOpacity onPress={onBack} style={styles.backButton}>
                <Ionicons name="arrow-back" size={24} color="#0A0D14" />
              </TouchableOpacity>
            )}
            <View style={styles.stepIndicatorContainer}>
              <Text style={styles.stepIndicator}>2 / 3 ШАГ</Text>
            </View>
            <TouchableOpacity onPress={onSkip || (() => {})} style={styles.skipButton}>
              <Text style={styles.skipButtonText}>Пропустить</Text>
            </TouchableOpacity>
          </View>

          {/* Title */}
          <Text style={styles.title}>Данные о вашем{'\n'}ресторане</Text>

          {/* Description */}
          <Text style={styles.description}>
            Укажите заведения, чтобы получить точный анализ по каждому направлению.
          </Text>

          {/* Input Fields (два верхних поля как на первом экране) */}
          <View style={styles.inputsContainer}>
            {/* Названия заведения */}
            <View style={styles.inputWrapper}>
              <Text style={styles.inputLabel}>Названия заведения</Text>
              <View style={styles.inputContainer}>
                {userIconSvg ? (
                  <View style={styles.inputIcon}>
                    <SvgXml xml={userIconSvg} width={20} height={20} />
                  </View>
                ) : (
                  <Ionicons name="person-outline" size={20} color={palette.gray400} style={styles.inputIcon} />
                )}
                <TextInput
                  style={styles.input}
                  placeholder="Суши-бар"
                  placeholderTextColor={palette.gray400}
                  value={name}
                  onChangeText={setName}
                />
              </View>
            </View>

            {/* Адрес заведения */}
            <View style={[styles.inputWrapper, styles.addressInputWrapper]}>
              <View style={styles.addressLabelRowAbsolute}>
                <Text style={styles.inputLabel}>Адрес заведения</Text>
                <Text style={styles.mapLinkText}>Указать на карте</Text>
              </View>
              <View style={[styles.inputContainer, styles.addressInputContainer]}>
                {emailIconSvg ? (
                  <View style={styles.inputIcon}>
                    <SvgXml xml={emailIconSvg} width={20} height={20} />
                  </View>
                ) : (
                  <Ionicons name="location-outline" size={20} color={palette.gray400} style={styles.inputIcon} />
                )}
                <TextInput
                  style={styles.input}
                  placeholder="Москва, ул. Пушкина, 1А"
                  placeholderTextColor={palette.gray400}
                  value={email}
                  onChangeText={setEmail}
                  keyboardType="email-address"
                  autoCapitalize="none"
                />
              </View>
            </View>
          </View>

          {/* Logo block (как на скрине под вторым полем) */}
          <View style={styles.logoSection}>
            <View style={styles.logoPreview}>
              {logoPlaceholderSvg ? (
                <SvgXml xml={logoPlaceholderSvg} width={50} height={50} />
              ) : (
                <Ionicons name="image-outline" size={30} color={palette.gray400} />
              )}
            </View>
            <View style={styles.logoTextContainer}>
              <Text style={styles.logoTitle}>Логотип</Text>
              <Text style={styles.logoSubtitle}>200x200px, png / jpg</Text>
            </View>
            <TouchableOpacity style={styles.logoUploadButton} activeOpacity={0.8}>
              <Text style={styles.logoUploadButtonText}>Загрузить</Text>
            </TouchableOpacity>
          </View>

          {/* Серая полоса под логотипом, как на дашборде */}
          <View style={styles.logoDivider} />

          {/* "+ Добавить еще ресторан" под серой линией */}
          <View style={styles.addRestaurantRow}>
            <Text style={styles.addRestaurantPlus}>+</Text>
            <Text style={styles.addRestaurantText}>Добавить еще ресторан</Text>
          </View>

        </View>
      </ScrollView>
      {/* Кнопка "Продолжить" - абсолютное позиционирование */}
      <View style={styles.continueButtonContainer}>
        <AnimatedPressable
          style={styles.continueButton}
          onPress={onContinue}
        >
          <Text style={styles.continueButtonText}>Продолжить</Text>
        </AnimatedPressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: palette.background,
  },
  scrollContent: {
    flexGrow: 1,
    paddingHorizontal: spacing.md,
    paddingTop: Platform.OS === 'ios' ? 60 : 40,
    paddingBottom: spacing.xl, // Точно как на первом экране
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.xl,
    position: 'relative',
  },
  backButton: {
    paddingVertical: spacing.xs,
    paddingRight: spacing.sm,
    zIndex: 3,
  },
  stepIndicatorContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 1,
  },
  stepIndicator: {
    fontSize: 14,
    fontWeight: '600',
    color: 'rgba(10, 13, 20, 0.5)',
    fontFamily: 'Manrope-SemiBold',
    textAlign: 'center',
    letterSpacing: 0.5,
  },
  skipButton: {
    paddingVertical: spacing.xs,
    paddingLeft: spacing.sm,
    paddingRight: 0,
    height: 'auto',
    marginLeft: 'auto', // Выравнивание справа
    zIndex: 2,
  },
  skipButtonText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#191BDF',
    fontFamily: 'Manrope-Medium',
    letterSpacing: 0.5,
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: '#0A0D14',
    fontFamily: 'Manrope-Bold',
    marginTop: -20,
    marginBottom: spacing.sm,
    lineHeight: 36,
    textAlign: 'center',
  },
  description: {
    fontSize: 16,
    fontWeight: '500',
    color: 'rgba(10, 13, 20, 0.8)',
    fontFamily: 'Manrope-Medium',
    marginBottom: spacing.xl,
    lineHeight: 24,
    textAlign: 'center',
  },
  inputsContainer: {
    marginBottom: spacing.lg,
  },
  inputWrapper: {
    marginBottom: spacing.lg,
  },
  addressLabelRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '100%',
    marginBottom: spacing.xs, // Отступ как у "Название заведения"
  },
  addressInputWrapper: {
    position: 'relative', // Для абсолютного позиционирования заголовка
  },
  addressLabelRowAbsolute: {
    position: 'absolute',
    top: 0, // Начало контейнера
    left: 0,
    right: 0,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '100%',
  },
  inputLabel: {
    fontSize: 15,
    fontWeight: '600',
    color: '#0A0D14',
    fontFamily: 'Manrope-SemiBold',
    marginBottom: spacing.xs, // Отступ как у "Адрес заведения"
  },
  mapLinkText: {
    fontSize: 14, // Как у "Выбрать все" на третьем экране
    fontWeight: '500', // Как у "Выбрать все"
    color: '#191BDF', // Как у "Выбрать все"
    fontFamily: 'Manrope-Medium', // Как у "Выбрать все"
    letterSpacing: 0.5, // Как у "Выбрать все"
    paddingRight: 0,
    transform: [{ translateY: -2 }], // Поднимаем на 2px для выравнивания с "Адрес заведения"
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: palette.white,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#E2E4E9',
    paddingHorizontal: spacing.md,
    height: 56,
  },
  addressInputContainer: {
    marginTop: spacing.xs + 22, // Отступ сверху для поля (spacing.xs 8px + высота заголовка ~22px) = такой же отступ как у "Название заведения"
  },
  inputIcon: {
    marginRight: spacing.sm,
  },
  input: {
    flex: 1,
    fontSize: 16,
    fontWeight: '500',
    color: '#3C4159',
    fontFamily: 'Manrope-Medium',
    padding: 0,
    includeFontPadding: false,
    textAlignVertical: 'center',
  },
  logoSection: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 0, // чтобы иконка и контент выровнялись по левому краю полей регистрации
    paddingVertical: spacing.md,
    marginTop: spacing.lg - 57, // Поднято ещё на 7 пикселей
  },
  logoPreview: {
    width: 56,
    height: 56,
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: spacing.md,
  },
  logoTextContainer: {
    flex: 1,
  },
  logoTitle: {
    fontSize: 17, // на 2 больше, чем у заголовка полей (15)
    fontWeight: '600', // как у заголовков полей регистрации
    color: '#0A0D14', // как у заголовков полей регистрации
    fontFamily: 'Manrope-SemiBold',
    marginBottom: 2, // уменьшен отступ, чтобы подпись подойти ближе к заголовку
  },
  logoSubtitle: {
    fontSize: 14, // на 2 меньше, чем было
    fontWeight: '500', // как у подзаголовка
    color: '#868C98', // как иконка в поле "Адрес заведения"
    fontFamily: 'Manrope-Medium',
    lineHeight: 20,
  },
  logoUploadButton: {
    paddingHorizontal: spacing.md,
    height: 40,
    borderRadius: 12, // как у полей регистрации
    borderWidth: 1,
    borderColor: '#E2E4E9', // как у полей регистрации
    backgroundColor: palette.white, // как у полей регистрации
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoUploadButtonText: {
    fontSize: 16, // как у подзаголовка
    fontWeight: '500', // как у подзаголовка
    color: '#6B7280', // немного темнее подписи под логотипом
    fontFamily: 'Manrope-Medium',
    lineHeight: 24,
  },
  logoDivider: {
    height: 1,
    backgroundColor: '#E2E4E9', // как тонкая серая полоса на дашборде
    marginTop: spacing.md, // отступ вниз от логотипа
    alignSelf: 'stretch', // ширина как у полей регистрации (учитывая paddingHorizontal scrollContent)
  },
  addRestaurantRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: spacing.md + 5, // опущено на 5 пикселей ниже линии
    marginBottom: spacing.md + 24, // Увеличено еще на 2px, чтобы кнопка была ниже
  },
  addRestaurantPlus: {
    fontSize: 20, // на 1 больше, чем текст (19)
    fontWeight: '500',
    color: '#0A0D14',
    fontFamily: 'Manrope-Bold',
    marginRight: -2, // промежуток с текстом
    transform: [{ translateX: -6 }], // сдвиг плюса влево на 6 пикселей
  },
  addRestaurantText: {
    fontSize: 19, // как было
    fontWeight: '500', // как было
    color: '#0A0D14', // как у "Адрес заведения"
    fontFamily: 'Manrope-Bold',
    textAlign: 'center',
  },
  continueButtonContainer: {
    position: 'absolute',
    bottom: 84 + 18, // Фактическая высота от низа экрана (32px + 36px + 16px) + дополнительно 18px для совпадения
    left: 0,
    right: 0,
    paddingHorizontal: spacing.md,
  },
  continueButton: {
    backgroundColor: '#191BDF', // Стили как у кнопки "План улучшений"
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    borderRadius: 99,
    alignItems: 'center',
    justifyContent: 'center',
  },
  continueButtonText: {
    fontSize: 18, // Как у кнопки "Начать" на онбординге
    fontWeight: '500', // Как у кнопки "Начать" на онбординге
    fontFamily: Platform.select({
      ios: 'Manrope',
      android: 'Manrope',
      web: "'Manrope', sans-serif",
      default: 'Manrope',
    }),
    color: palette.white, // Как у кнопки "Начать" на онбординге
    textAlign: 'center',
  },
});

