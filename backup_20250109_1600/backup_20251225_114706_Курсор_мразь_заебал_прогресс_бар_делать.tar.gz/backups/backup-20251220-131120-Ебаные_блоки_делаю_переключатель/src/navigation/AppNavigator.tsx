import { Ionicons } from '@expo/vector-icons';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { CommonActions } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { Asset } from 'expo-asset';
import React, { useEffect, useState } from 'react';
import { Platform, Text, StyleSheet, View } from 'react-native';
import { SvgXml } from 'react-native-svg';

import ActionPlanScreen from '../screens/ActionPlanScreen';
import AIAssistantScreen from '../screens/AIAssistantScreen';
import BlockDetailScreen from '../screens/BlockDetailScreen';
import BlockQuestionsScreen from '../screens/BlockQuestionsScreen';
import DashboardScreen from '../screens/DashboardScreen';
import HelpScreen from '../screens/HelpScreen';
import HistoryScreen from '../screens/HistoryScreen';
import ProfileScreen from '../screens/ProfileScreen';
import SelfDiagnosisBlocksScreen from '../screens/SelfDiagnosisBlocksScreen';
import { clearDataOnAppLaunch } from '../utils/appState';

// Фирменные цвета
const COLORS = {
  orange: '#E84411',
  blue: '#112677',
  gray: '#F0F0F0',
  white: '#FFFFFF',
  darkGray: '#666666',
  inactive: '#868C98',
  active: '#375DFB',
};

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

function HomeStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen 
        name="SelfDiagnosisBlocks" 
        component={SelfDiagnosisBlocksScreen} 
        options={{ headerShown: false }} 
      />
      <Stack.Screen 
        name="BlockQuestions" 
        component={BlockQuestionsScreen} 
        options={{ title: 'Вопросы блока' }} 
      />
    </Stack.Navigator>
  );
}

function DashboardStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="DashboardMain" component={DashboardScreen} />
      <Stack.Screen 
        name="BlockDetail" 
        component={BlockDetailScreen} 
      />
      <Stack.Screen 
        name="Help" 
        component={HelpScreen}
        options={{
          tabBarStyle: { display: 'none' },
        }}
        listeners={{
          focus: () => {
            // Скрываем таб-бар при открытии экрана Help
          },
        }}
      />
    </Stack.Navigator>
  );
}

function ActionPlanStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="ActionPlanMain" component={ActionPlanScreen} />
      <Stack.Screen name="BlockDetail" component={BlockDetailScreen} />
    </Stack.Navigator>
  );
}

export default function AppNavigator() {
  const [homeIconSvg, setHomeIconSvg] = useState<string>('');
  const [taskIconSvg, setTaskIconSvg] = useState<string>('');
  const [diagnosisIconSvg, setDiagnosisIconSvg] = useState<string>('');
  const [aiAgentIconSvg, setAiAgentIconSvg] = useState<string>('');
  const [userIconSvg, setUserIconSvg] = useState<string>('');

  useEffect(() => {
    clearDataOnAppLaunch();
    
    // Загружаем SVG иконку для главной
    const loadHomeIcon = async () => {
      try {
        const iconAsset = Asset.fromModule(require('../../assets/images/home-02-icon.svg'));
        await iconAsset.downloadAsync();
        if (iconAsset.localUri) {
          const response = await fetch(iconAsset.localUri);
          const fileContent = await response.text();
          setHomeIconSvg(fileContent);
        }
      } catch (error) {
        console.error('Ошибка загрузки SVG иконки главной:', error);
      }
    };
    
    // Загружаем SVG иконку для задач
    const loadTaskIcon = async () => {
      try {
        const iconAsset = Asset.fromModule(require('../../assets/images/task-daily-icon.svg'));
        await iconAsset.downloadAsync();
        if (iconAsset.localUri) {
          const response = await fetch(iconAsset.localUri);
          const fileContent = await response.text();
          setTaskIconSvg(fileContent);
        }
      } catch (error) {
        console.error('Ошибка загрузки SVG иконки задач:', error);
      }
    };
    
    // Загружаем SVG иконку для диагностики
    const loadDiagnosisIcon = async () => {
      try {
        const iconAsset = Asset.fromModule(require('../../assets/images/dashboard-speed-icon.svg'));
        await iconAsset.downloadAsync();
        if (iconAsset.localUri) {
          const response = await fetch(iconAsset.localUri);
          const fileContent = await response.text();
          setDiagnosisIconSvg(fileContent);
        }
      } catch (error) {
        console.error('Ошибка загрузки SVG иконки диагностики:', error);
      }
    };
    
    // Загружаем SVG иконку для AI-агента
    const loadAiAgentIcon = async () => {
      try {
        const iconAsset = Asset.fromModule(require('../../assets/images/stars-icon.svg'));
        await iconAsset.downloadAsync();
        if (iconAsset.localUri) {
          const response = await fetch(iconAsset.localUri);
          const fileContent = await response.text();
          setAiAgentIconSvg(fileContent);
        }
      } catch (error) {
        console.error('Ошибка загрузки SVG иконки AI-агента:', error);
      }
    };
    
    // Загружаем SVG иконку для профиля
    const loadUserIcon = async () => {
      try {
        const iconAsset = Asset.fromModule(require('../../assets/images/user-icon.svg'));
        await iconAsset.downloadAsync();
        if (iconAsset.localUri) {
          const response = await fetch(iconAsset.localUri);
          const fileContent = await response.text();
          setUserIconSvg(fileContent);
        }
      } catch (error) {
        console.error('Ошибка загрузки SVG иконки профиля:', error);
      }
    };
    
    loadHomeIcon();
    loadTaskIcon();
    loadDiagnosisIcon();
    loadAiAgentIcon();
    loadUserIcon();
  }, []);

  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: COLORS.active,
        tabBarInactiveTintColor: COLORS.inactive,
        // Отключаем изменение URL на вебе
        ...(Platform.OS === 'web' && {
          linking: {
            enabled: false,
          },
        }),
        tabBarStyle: {
          backgroundColor: COLORS.white,
          borderTopColor: COLORS.gray,
          borderTopWidth: 1,
          paddingBottom: 6,
          paddingTop: -8,
          height: 70,
          paddingHorizontal: 0,
        },
        tabBarLabelStyle: {
          fontSize: 11,
          fontWeight: '400',
          marginTop: 0,
        },
        tabBarItemStyle: {
          paddingHorizontal: 0,
        },
      }}
    >
      <Tab.Screen 
        name="Главная" 
        component={DashboardStack}
        options={{
          tabBarLabel: 'Главная',
          tabBarStyle: {
            backgroundColor: COLORS.white,
            borderTopColor: COLORS.gray,
            borderTopWidth: 1,
            paddingBottom: 6,
            paddingTop: -8,
            height: 70,
            paddingHorizontal: 0,
          },
          tabBarLabelStyle: {
            fontSize: 11,
            fontWeight: '400',
            marginTop: 0,
          },
          tabBarItemStyle: {
            paddingHorizontal: 0,
          },
          tabBarIcon: ({ focused, color, size }) => {
            if (homeIconSvg) {
              const iconColor = focused ? COLORS.active : COLORS.inactive;
              const coloredSvg = homeIconSvg.replace(/#868C98/g, iconColor);
              return (
                <View style={{ marginTop: -3 }}>
                  <SvgXml 
                    xml={coloredSvg} 
                    width={23} 
                    height={23}
                  />
                </View>
              );
            }
            return (
              <View style={{ marginTop: -3 }}>
                <Ionicons 
                  name={focused ? 'home' : 'home-outline'} 
                  size={23} 
                  color={focused ? COLORS.active : COLORS.inactive} 
                />
              </View>
            );
          },
        }}
        listeners={({ navigation }) => ({
          tabPress: (e) => {
            // Если уже на табе "Главная", сбрасываем стек навигации до корневого экрана
            const state = navigation.getState();
            const mainTabRoute = state.routes.find(r => r.name === 'Главная');
            
            if (mainTabRoute && mainTabRoute.state && mainTabRoute.state.index > 0) {
              // Если в стеке есть экраны кроме корневого, сбрасываем стек
              e.preventDefault();
              
              // Сбрасываем стек навигации внутри таба "Главная"
              navigation.dispatch(
                CommonActions.reset({
                  index: 0,
                  routes: [
                    {
                      name: 'Главная',
                      state: {
                        routes: [{ name: 'DashboardMain' }],
                        index: 0,
                      },
                    },
                  ],
                })
              );
            }
          },
        })}
      />
      <Tab.Screen 
        name="Задачи" 
        component={ActionPlanStack}
        options={{
          tabBarLabel: 'Задачи',
          tabBarStyle: {
            backgroundColor: COLORS.white,
            borderTopColor: COLORS.gray,
            borderTopWidth: 1,
            paddingBottom: 6,
            paddingTop: -8,
            height: 70,
            paddingHorizontal: 0,
          },
          tabBarLabelStyle: {
            fontSize: 11,
            fontWeight: '400',
            marginTop: 0,
          },
          tabBarItemStyle: {
            paddingHorizontal: 0,
          },
          tabBarIcon: ({ focused, color, size }) => {
            if (taskIconSvg) {
              const iconColor = focused ? COLORS.active : COLORS.inactive;
              const coloredSvg = taskIconSvg.replace(/#868C98/g, iconColor);
              return (
                <View style={{ marginTop: -3 }}>
                  <SvgXml 
                    xml={coloredSvg} 
                    width={23} 
                    height={23}
                  />
                </View>
              );
            }
            return (
              <View style={{ marginTop: -3 }}>
                <Ionicons 
                  name={focused ? 'checkmark-circle' : 'checkmark-circle-outline'} 
                  size={23} 
                  color={focused ? COLORS.active : COLORS.inactive} 
                />
              </View>
            );
          },
        }}
      />
      <Tab.Screen 
        name="Диагностика" 
        component={HomeStack}
        options={{
          tabBarLabel: 'Диагностика',
          tabBarStyle: {
            backgroundColor: COLORS.white,
            borderTopColor: COLORS.gray,
            borderTopWidth: 1,
            paddingBottom: 6,
            paddingTop: -8,
            height: 70,
            paddingHorizontal: 0,
          },
          tabBarLabelStyle: {
            fontSize: 11,
            fontWeight: '400',
            marginTop: 0,
          },
          tabBarItemStyle: {
            paddingHorizontal: 0,
            minWidth: 95,
            maxWidth: 95,
          },
          tabBarIcon: ({ focused, color, size }) => {
            if (diagnosisIconSvg) {
              const iconColor = focused ? COLORS.active : COLORS.inactive;
              const coloredSvg = diagnosisIconSvg.replace(/#868C98/g, iconColor);
              return (
                <View style={{ marginTop: -3 }}>
                  <SvgXml 
                    xml={coloredSvg} 
                    width={23} 
                    height={23}
                  />
                </View>
              );
            }
            return (
              <View style={{ marginTop: -3 }}>
                <Ionicons 
                  name={focused ? 'add-circle' : 'add-circle-outline'} 
                  size={23} 
                  color={focused ? COLORS.active : COLORS.inactive} 
                />
              </View>
            );
          },
        }}
      />
      <Tab.Screen 
        name="AI-агент" 
        component={AIAssistantScreen}
        options={{
          tabBarLabel: 'AI-агент',
          tabBarStyle: {
            backgroundColor: COLORS.white,
            borderTopColor: COLORS.gray,
            borderTopWidth: 1,
            paddingBottom: 6,
            paddingTop: -8,
            height: 70,
            paddingHorizontal: 0,
          },
          tabBarLabelStyle: {
            fontSize: 11,
            fontWeight: '400',
            marginTop: 0,
          },
          tabBarItemStyle: {
            paddingHorizontal: 0,
          },
          tabBarIcon: ({ focused, color, size }) => {
            if (aiAgentIconSvg) {
              const iconColor = focused ? COLORS.active : COLORS.inactive;
              const coloredSvg = aiAgentIconSvg.replace(/#868C98/g, iconColor);
              return (
                <View style={{ marginTop: -3 }}>
                  <SvgXml 
                    xml={coloredSvg} 
                    width={23} 
                    height={23}
                  />
                </View>
              );
            }
            return (
              <View style={{ marginTop: -3 }}>
                <Ionicons 
                  name={focused ? 'chatbubble' : 'chatbubble-outline'} 
                  size={23} 
                  color={focused ? COLORS.active : COLORS.inactive} 
                />
              </View>
            );
          },
        }}
      />
      <Tab.Screen 
        name="Профиль" 
        component={ProfileScreen}
        options={{
          tabBarLabel: 'Профиль',
          tabBarStyle: {
            backgroundColor: COLORS.white,
            borderTopColor: COLORS.gray,
            borderTopWidth: 1,
            paddingBottom: 6,
            paddingTop: -8,
            height: 70,
            paddingHorizontal: 0,
          },
          tabBarLabelStyle: {
            fontSize: 11,
            fontWeight: '400',
            marginTop: 0,
          },
          tabBarItemStyle: {
            paddingHorizontal: 0,
          },
          tabBarIcon: ({ focused, color, size }) => {
            if (userIconSvg) {
              const iconColor = focused ? COLORS.active : COLORS.inactive;
              const coloredSvg = userIconSvg.replace(/#868C98/g, iconColor);
              return (
                <View style={{ marginTop: -3 }}>
                  <SvgXml 
                    xml={coloredSvg} 
                    width={23} 
                    height={23}
                  />
                </View>
              );
            }
            return (
              <View style={{ marginTop: -3 }}>
                <Ionicons 
                  name={focused ? 'person' : 'person-outline'} 
                  size={23} 
                  color={focused ? COLORS.active : COLORS.inactive} 
                />
              </View>
            );
          },
        }}
      />
    </Tab.Navigator>
  );
}