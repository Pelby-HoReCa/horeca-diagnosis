import AsyncStorage from '@react-native-async-storage/async-storage';
import { NavigationContainer } from '@react-navigation/native';
import { useFonts, Manrope_300Light, Manrope_400Regular, Manrope_500Medium, Manrope_600SemiBold, Manrope_700Bold, Manrope_800ExtraBold } from '@expo-google-fonts/manrope';
import React, { createContext, useContext, useEffect, useState } from 'react';
import { View } from 'react-native';

import AppNavigator from '../navigation/AppNavigator';
import OnboardingScreen1 from '../screens/OnboardingScreen1';
import OnboardingScreen2 from '../screens/OnboardingScreen2';
import OnboardingScreen3 from '../screens/OnboardingScreen3';
import RegisterScreen1 from '../screens/RegisterScreen1';
import RegisterScreen2 from '../screens/RegisterScreen2';
import RegisterScreen3 from '../screens/RegisterScreen3';
import SplashScreen from '../screens/SplashScreen';

// Контекст для управления переходом к авторизации (оставлен для совместимости)
interface AppContextType {
  navigateToAuth: () => void;
}

const AppContext = createContext<AppContextType | null>(null);

export const useAppContext = () => {
  const context = useContext(AppContext);
  return context;
};

export default function AppWrapper() {
  const [currentScreen, setCurrentScreen] = useState<
    'splash' | 'onboarding1' | 'onboarding2' | 'onboarding3' | 'register1' | 'register2' | 'register3' | 'main'
  >('splash');

  const [fontsLoaded] = useFonts({
    'Manrope-Light': Manrope_300Light,
    'Manrope-Regular': Manrope_400Regular,
    'Manrope-Medium': Manrope_500Medium,
    'Manrope-SemiBold': Manrope_600SemiBold,
    'Manrope-Bold': Manrope_700Bold,
    'Manrope-ExtraBold': Manrope_800ExtraBold,
  });

  useEffect(() => {
    // Очищаем hasSeenOnboarding, чтобы всегда показывать онбординг
    AsyncStorage.removeItem('hasSeenOnboarding');
  }, []);

  const handleSplashFinish = () => {
    setCurrentScreen('onboarding1');
  };

  const handleOnboarding1Continue = () => {
    setCurrentScreen('onboarding2');
  };

  const handleOnboarding2Continue = () => {
    setCurrentScreen('onboarding3');
  };

  const handleOnboarding3Continue = async () => {
    console.log('Onboarding3 продолжение - переходим на регистрацию');
    await AsyncStorage.setItem('hasSeenOnboarding', 'true');
    setCurrentScreen('register1');
    console.log('Экран установлен на register1');
  };

  const handleRegister1Continue = () => {
    setCurrentScreen('register2');
  };

  const handleRegister1Skip = () => {
    console.log('Пропустить - переходим на второй экран регистрации');
    setCurrentScreen('register2'); // Переводит на второй экран регистрации
  };

  const handleRegister2Continue = () => {
    // "Продолжить" на втором экране регистрации ведёт сразу в основное приложение
    setCurrentScreen('main');
  };

  const handleRegister2Skip = () => {
    // "Пропустить" на втором экране регистрации ведёт на третий экран регистрации
    setCurrentScreen('register3');
  };

  const handleRegister3Continue = () => {
    // С третьего экрана регистрации (когда появится контент) идём в основное приложение
    setCurrentScreen('main');
  };

  const handleRegister3Skip = () => {
    // "Пропустить" на третьем экране ведёт в основное приложение (дашборд)
    console.log('Пропустить на экране 3 - переходим на дашборд');
    setCurrentScreen('main');
  };

  // Пустая функция для совместимости с ProfileScreen
  const navigateToAuth = () => {
    // Авторизация отключена
  };

  const contextValue: AppContextType = {
    navigateToAuth,
  };

  if (currentScreen === 'splash') {
    return <SplashScreen onFinish={handleSplashFinish} />;
  }

  if (currentScreen === 'onboarding1') {
    return <OnboardingScreen1 onContinue={handleOnboarding1Continue} />;
  }

  if (currentScreen === 'onboarding2') {
    return <OnboardingScreen2 onContinue={handleOnboarding2Continue} />;
  }

  if (currentScreen === 'onboarding3') {
    return <OnboardingScreen3 onContinue={handleOnboarding3Continue} />;
  }

  if (currentScreen === 'register1') {
    console.log('Отображаем экран регистрации');
    return <RegisterScreen1 onContinue={handleRegister1Continue} onSkip={handleRegister1Skip} />;
  }

  if (currentScreen === 'register2') {
    console.log('Отображаем второй экран регистрации');
    return <RegisterScreen2 onContinue={handleRegister2Continue} onSkip={handleRegister2Skip} />;
  }

  if (currentScreen === 'register3') {
    console.log('Отображаем третий экран регистрации');
    return <RegisterScreen3 onContinue={handleRegister3Continue} onSkip={handleRegister3Skip} />;
  }

  return (
    <AppContext.Provider value={contextValue}>
      <NavigationContainer>
        <AppNavigator />
      </NavigationContainer>
    </AppContext.Provider>
  );
}
