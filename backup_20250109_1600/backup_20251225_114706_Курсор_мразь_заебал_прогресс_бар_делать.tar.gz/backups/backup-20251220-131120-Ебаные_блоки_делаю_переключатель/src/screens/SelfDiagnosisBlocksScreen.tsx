import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect } from '@react-navigation/native';
import { Asset } from 'expo-asset';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { FlatList, Image, ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { SvgXml } from 'react-native-svg';
import AnimatedPressable from '../components/AnimatedPressable';
import { DEFAULT_BLOCKS, DiagnosisBlock } from '../data/diagnosisBlocks';
import { palette, radii, spacing, typography } from '../styles/theme';
import { getCurrentUserId, loadUserBlocks, loadUserQuestionnaire, saveUserBlocks } from '../utils/userDataStorage';

const logo = require('../../assets/images/logo-pelby.png');

export default function SelfDiagnosisBlocksScreen({ navigation }: any) {
  const [blocks, setBlocks] = useState<DiagnosisBlock[]>([]);
  const [loading, setLoading] = useState(true);
  const [showScrollButton, setShowScrollButton] = useState(false);
  const flatListRef = useRef<FlatList>(null);
  const [restaurantName, setRestaurantName] = useState('Проект');
  const [city, setCity] = useState<string>('');
  const [projectAvatarUri, setProjectAvatarUri] = useState<string | null>(null);
  const [cityIconSvg, setCityIconSvg] = useState<string>('');
  const [helpButtonIconSvg, setHelpButtonIconSvg] = useState<string>('');
  const [refreshIconSvg, setRefreshIconSvg] = useState<string>('');
  const [addIconSvg, setAddIconSvg] = useState<string>('');
  const [activeTab, setActiveTab] = useState<string>('Все');

  useEffect(() => {
    console.log('Компонент загружен, инициализируем...');
    loadBlocks();
    loadProfileData();
    loadIcons();
  }, []);

  const loadProfileData = async () => {
    try {
      const userId = await getCurrentUserId();
      
      if (userId) {
        const questionnaireData = await loadUserQuestionnaire(userId);
        if (questionnaireData && questionnaireData.restaurantName && questionnaireData.restaurantName.trim()) {
          setRestaurantName(questionnaireData.restaurantName);
        } else {
          setRestaurantName('Проект');
        }
        
        if (questionnaireData && questionnaireData.city) {
          setCity(questionnaireData.city);
        }
      } else {
        setRestaurantName('Проект');
      }
      
      const savedProjectAvatar = await AsyncStorage.getItem('projectAvatar');
      if (savedProjectAvatar) {
        setProjectAvatarUri(savedProjectAvatar);
      }
    } catch (error) {
      console.error('Ошибка загрузки данных профиля:', error);
    }
  };

  const loadIcons = async () => {
    // Загружаем SVG иконку для города
    const loadCityIcon = async () => {
      try {
        const iconAsset = Asset.fromModule(require('../../assets/images/arrow-down-city.svg'));
        await iconAsset.downloadAsync();
        if (iconAsset.localUri) {
          const response = await fetch(iconAsset.localUri);
          const fileContent = await response.text();
          setCityIconSvg(fileContent);
        }
      } catch (error) {
        console.error('Ошибка загрузки SVG иконки города:', error);
      }
    };
    
    // Загружаем SVG иконку для кнопки помощи
    const loadHelpButtonIcon = async () => {
      try {
        const iconAsset = Asset.fromModule(require('../../assets/images/help-button-icon.svg'));
        await iconAsset.downloadAsync();
        if (iconAsset.localUri) {
          const response = await fetch(iconAsset.localUri);
          const fileContent = await response.text();
          setHelpButtonIconSvg(fileContent);
        }
      } catch (error) {
        console.error('Ошибка загрузки SVG иконки кнопки помощи:', error);
      }
    };
    
    // Загружаем SVG иконки для секции "Общая эффективность"
    const loadEfficiencyIcons = async () => {
      try {
        // Иконка обновления (часов)
        const refreshAsset = Asset.fromModule(require('../../assets/images/refresh-icon.svg'));
        await refreshAsset.downloadAsync();
        if (refreshAsset.localUri) {
          const response = await fetch(refreshAsset.localUri);
          const fileContent = await response.text();
          setRefreshIconSvg(fileContent);
        }
        
        // Иконка добавления (плюсик)
        const addAsset = Asset.fromModule(require('../../assets/images/add-icon.svg'));
        await addAsset.downloadAsync();
        if (addAsset.localUri) {
          const response = await fetch(addAsset.localUri);
          const fileContent = await response.text();
          setAddIconSvg(fileContent);
        }
      } catch (error) {
        console.error('Ошибка загрузки SVG иконок эффективности:', error);
      }
    };
    
    loadCityIcon();
    loadHelpButtonIcon();
    loadEfficiencyIcons();
  };

  // Обновляем блоки при возврате на экран (БЕЗ очистки данных)
  useFocusEffect(
    useCallback(() => {
      console.log('Экран блоков получил фокус, обновляем блоки...');
      loadBlocksWithoutClearing();
    }, [])
  );


  const mergeBlocksWithDefaults = (source: DiagnosisBlock[]): DiagnosisBlock[] =>
    DEFAULT_BLOCKS.map(defaultBlock => {
      const storedBlock = source.find(block => block.id === defaultBlock.id);
      return storedBlock ? { ...defaultBlock, ...storedBlock } : defaultBlock;
    });

  const persistBlocks = async (blocksToSave: DiagnosisBlock[]) => {
    try {
      await AsyncStorage.setItem('diagnosisBlocks', JSON.stringify(blocksToSave));
      const userId = await getCurrentUserId();
      if (userId) {
        await saveUserBlocks(userId, blocksToSave);
      }
    } catch (error) {
      console.error('Ошибка сохранения блоков:', error);
    }
  };

  const fetchBlocks = async (): Promise<DiagnosisBlock[]> => {
    let blocksSource: DiagnosisBlock[] = [];

    try {
      const userId = await getCurrentUserId();

      if (userId) {
        const userBlocks = await loadUserBlocks(userId);
        if (Array.isArray(userBlocks) && userBlocks.length) {
          blocksSource = userBlocks;
        }
      }

      if (!blocksSource.length) {
        const storedBlocks = await AsyncStorage.getItem('diagnosisBlocks');
        if (storedBlocks) {
          blocksSource = JSON.parse(storedBlocks);
        }
      }
    } catch (error) {
      console.error('Ошибка получения блоков:', error);
    }

    if (!blocksSource.length) {
      return DEFAULT_BLOCKS;
    }

    return mergeBlocksWithDefaults(blocksSource);
  };

  const loadBlocksWithoutClearing = async () => {
    try {
      console.log('Загружаем блоки без очистки...');
      const allBlocks = await fetchBlocks();
      setBlocks(allBlocks);
      await persistBlocks(allBlocks);
      console.log('Блоки обновлены в состоянии:', allBlocks.length);
    } catch (error) {
      console.error('Ошибка загрузки блоков:', error);
    }
  };


  // Принудительная инициализация блоков, если они пустые
  useEffect(() => {
    if (!loading && blocks.length === 0) {
      setBlocks(DEFAULT_BLOCKS);
    }
  }, [loading, blocks.length]);

  const loadBlocks = async () => {
    try {
      console.log('Загружаем блоки диагностики...');
      const allBlocks = await fetchBlocks();
      setBlocks(allBlocks);
      await persistBlocks(allBlocks);
      console.log('Блоки загружены и сохранены');
    } catch (error) {
      console.error('Ошибка загрузки блоков:', error);
      // В случае ошибки показываем блоки по умолчанию
      setBlocks(DEFAULT_BLOCKS);
    } finally {
      setLoading(false);
    }
  };
  const handleBlockPress = (block: DiagnosisBlock) => {
    console.log('Нажата карточка блока:', block.title);
    // Переходим сразу к вопросам блока
    navigation.navigate('BlockQuestions', { blockId: block.id, blockTitle: block.title });
  };

  const getEfficiencyColor = (efficiency?: number): { bg: string; text: string; border?: string } => {
    if (efficiency === undefined || efficiency === null) {
      return { bg: palette.gray200, text: palette.gray500 };
    }

    if (efficiency >= 80) {
      return { bg: '#E6F7F1', text: palette.success, border: '#81C784' };
    } else if (efficiency >= 60) {
      return { bg: '#E5EBFF', text: palette.primaryBlue, border: '#A7B5FF' };
    } else if (efficiency >= 40) {
      return { bg: '#FFF4E6', text: palette.primaryOrange, border: '#FFBE7B' };
    } else {
      return { bg: '#FFE9EC', text: palette.error, border: '#FF9AA4' };
    }
  };

  const renderBlock = ({ item }: { item: DiagnosisBlock }) => {
    const colors = getEfficiencyColor(item.efficiency);
    
    return (
      <AnimatedPressable
        style={[
          styles.blockCard,
          { 
            backgroundColor: palette.white,
            borderColor: item.completed ? (colors.border || colors.text) : palette.gray200,
            borderLeftWidth: item.completed ? 6 : 1,
            borderLeftColor: colors.border || palette.gray300
          }
        ]}
        onPress={() => handleBlockPress(item)}
      >
        <View style={styles.blockHeader}>
          <Text style={styles.blockTitle}>{item.title}</Text>
          {item.completed && (
            <Ionicons name="checkmark-circle" size={22} color={palette.primaryOrange} />
          )}
        </View>
        <Text style={styles.blockDescription}>{item.description}</Text>
        {item.completed && item.efficiency !== undefined ? (
          <View style={styles.efficiencyContainer}>
            <Text style={[styles.efficiencyValue, { color: colors.text }]}>
              {item.efficiency}%
            </Text>
            <Text style={[styles.efficiencyLabel, { color: colors.text }]}>эффективность</Text>
          </View>
        ) : (
          <View style={styles.efficiencyContainer}>
            <Text style={[styles.efficiencyValue, { color: palette.gray500 }]}>—</Text>
            <Text style={[styles.efficiencyLabel, { color: palette.gray500 }]}>не пройдено</Text>
          </View>
        )}
      </AnimatedPressable>
    );
  };

  const completedCount = blocks.filter(block => block.completed).length;

  return (
    <View style={styles.container}>
      {/* Секция профиля проекта */}
      <View style={[styles.section, styles.profileSection]}>
        <View style={styles.profileInfo}>
          {/* Аватар компании */}
          <View style={styles.avatarContainer}>
            {projectAvatarUri ? (
              <Image source={{ uri: projectAvatarUri }} style={styles.avatarImage} />
            ) : (
              <View style={styles.avatarPlaceholder}>
                <Ionicons name="business" size={32} color={palette.gray400} />
              </View>
            )}
          </View>
          
          {/* Название и город */}
          <View style={styles.projectInfo}>
            <Text style={styles.projectName}>Проект</Text>
            <View style={styles.cityContainer}>
              <Text style={styles.cityText}>{city || 'город'}</Text>
              {cityIconSvg && (
                <View style={styles.cityIconContainer}>
                  <SvgXml xml={cityIconSvg} width={16} height={16} />
                </View>
              )}
            </View>
          </View>
        </View>
        
        {/* Кнопка Помощь PELBY */}
        <AnimatedPressable 
          style={styles.helpButton}
          onPress={() => {
            if (navigation) {
              navigation.navigate('Help');
            }
          }}
        >
          {helpButtonIconSvg ? (
            <View style={styles.helpButtonIconContainer}>
              <SvgXml xml={helpButtonIconSvg} width={18} height={18} />
            </View>
          ) : null}
          <Text style={styles.helpButtonText}>Помощь PELBY</Text>
        </AnimatedPressable>
      </View>

      {/* Секция с иконками часов и плюсика */}
      <View style={[styles.section, styles.efficiencySection]}>
        <View style={styles.efficiencyHeader}>
          <View style={styles.efficiencyTitleContainer}>
            <Text style={styles.efficiencyTitle}>Диагностика</Text>
          </View>
          <View style={styles.efficiencyIcons}>
            {refreshIconSvg && (
              <AnimatedPressable style={styles.iconButton}>
                <SvgXml xml={refreshIconSvg} width={38} height={38} />
              </AnimatedPressable>
            )}
            {addIconSvg && (
              <AnimatedPressable style={styles.iconButton}>
                <SvgXml xml={addIconSvg} width={38} height={38} />
              </AnimatedPressable>
            )}
          </View>
        </View>
      </View>

      {/* Секции-табы */}
      <View style={styles.tabsContainer}>
        <ScrollView 
          horizontal 
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.tabsScrollContent}
        >
          <TouchableOpacity 
            style={[
              styles.tabButton,
              activeTab === 'Все' && styles.tabButtonActive
            ]}
            onPress={() => setActiveTab('Все')}
          >
            <Text style={[
              styles.tabButtonText,
              activeTab === 'Все' && styles.tabButtonTextActive
            ]}>
              Все
            </Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={[
              styles.tabButton,
              activeTab === 'К прохождению' && styles.tabButtonActive
            ]}
            onPress={() => setActiveTab('К прохождению')}
          >
            <Text style={[
              styles.tabButtonText,
              activeTab === 'К прохождению' && styles.tabButtonTextActive
            ]}>
              К прохождению
            </Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={[
              styles.tabButton,
              activeTab === 'Начатые' && styles.tabButtonActive
            ]}
            onPress={() => setActiveTab('Начатые')}
          >
            <Text style={[
              styles.tabButtonText,
              activeTab === 'Начатые' && styles.tabButtonTextActive
            ]}>
              Начатые
            </Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={[
              styles.tabButton,
              activeTab === 'Завершенные' && styles.tabButtonActive
            ]}
            onPress={() => setActiveTab('Завершенные')}
          >
            <Text style={[
              styles.tabButtonText,
              activeTab === 'Завершенные' && styles.tabButtonTextActive
            ]}>
              Завершенные
            </Text>
          </TouchableOpacity>
        </ScrollView>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: palette.background,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: palette.background,
  },
  loadingText: {
    fontSize: 16,
    color: palette.primaryBlue,
  },
  header: {
    paddingHorizontal: spacing.md,
    paddingTop: spacing.xxl,
    paddingBottom: spacing.md,
    backgroundColor: palette.background,
    marginBottom: spacing.sm,
  },
  headerTop: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 60,
    marginBottom: spacing.xs,
  },
  headerTitleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerLogo: {
    width: 28,
    height: 28,
    marginRight: spacing.sm,
  },
  headerTitle: {
    ...typography.heading2,
    color: palette.primaryBlue,
  },
  startButtonContainer: {
    position: 'relative',
    marginTop: spacing.xs,
  },
  progress: {
    fontSize: 14,
    color: palette.primaryOrange,
    fontWeight: '600',
    textAlign: 'right',
    marginTop: spacing.sm,
    paddingRight: spacing.xs,
  },
  emptyText: {
    fontSize: 16,
    color: palette.gray600,
    textAlign: 'center',
    marginTop: spacing.lg,
  },
  listContainer: {
    paddingHorizontal: spacing.md,
    paddingBottom: spacing.xxl,
  },
  blockCard: {
    backgroundColor: palette.white,
    padding: spacing.md,
    borderRadius: radii.lg,
    marginBottom: spacing.md,
    borderWidth: 1,
    borderColor: palette.gray200,
    shadowColor: palette.midnightBlue,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.05,
    shadowRadius: 16,
    elevation: 4,
    minHeight: 120,
  },
  blockHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  blockTitle: {
    ...typography.heading3,
    color: palette.primaryBlue,
    flex: 1,
  },
  blockDescription: {
    fontSize: 14,
    color: palette.gray600,
    lineHeight: 20,
    marginBottom: spacing.sm,
  },
  efficiencyContainer: {
    alignItems: 'center',
    marginTop: spacing.xs,
  },
  efficiencyValue: {
    fontSize: 26,
    fontWeight: '700',
    marginBottom: spacing.xs,
  },
  efficiencyLabel: {
    fontSize: 11,
    fontWeight: '500',
    textTransform: 'uppercase',
    color: palette.gray600,
    letterSpacing: 0.5,
  },
  // Секция профиля проекта
  profileSection: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingRight: 0,
    paddingVertical: spacing.md,
    marginTop: spacing.xxl,
    marginBottom: spacing.lg,
    marginRight: spacing.md,
    marginLeft: spacing.sm,
  },
  profileInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    transform: [{ translateY: -2 }],
  },
  avatarContainer: {
    marginRight: 2,
  },
  avatarImage: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: palette.gray100,
  },
  avatarPlaceholder: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: palette.gray100,
    justifyContent: 'center',
    alignItems: 'center',
  },
  projectInfo: {
    flex: 1,
    transform: [{ translateY: -2 }],
  },
  projectName: {
    fontSize: 18,
    fontWeight: '400',
    color: '#0A0D14',
    marginBottom: spacing.xxs,
    marginTop: 0,
    marginLeft: -1,
    transform: [{ translateY: 2 }],
  },
  cityContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  cityText: {
    fontSize: 14,
    color: palette.gray600,
    marginRight: 2,
  },
  cityIconContainer: {
    marginLeft: 2,
    transform: [{ translateY: 1 }],
  },
  helpButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FD680A',
    paddingLeft: 6,
    paddingRight: 6,
    paddingVertical: 6,
    height: 32,
    borderRadius: 999,
    marginLeft: -1,
    transform: [{ translateY: -2 }],
  },
  helpButtonIconContainer: {
    marginRight: 2,
    marginLeft: 0,
  },
  helpButtonText: {
    fontSize: 14,
    fontWeight: '300',
    color: palette.white,
    lineHeight: 16,
    transform: [{ translateY: 0 }, { translateX: -1 }],
  },
  section: {
    marginHorizontal: spacing.md,
    marginBottom: spacing.md,
  },
  efficiencySection: {
    marginLeft: spacing.sm,
    marginRight: spacing.md,
    marginBottom: 0, // Убираем отступ снизу, чтобы контролировать расстояние до табов
  },
  efficiencyHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: spacing.md - 48, // Опущено на 2 пикселя (было -50, стало -48)
    marginBottom: spacing.sm,
  },
  efficiencyTitleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  efficiencyTitle: {
    fontSize: 27,
    fontWeight: '400',
    color: '#0A0D14',
    marginLeft: 5,
  },
  efficiencyIcons: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
  },
  iconButton: {
    // Убрали padding, чтобы иконки выравнивались как метрики ниже
  },
  tabsContainer: {
    marginTop: spacing.lg - spacing.sm - 2, // Поднято на 2 пикселя вверх
    marginBottom: spacing.md,
  },
  tabsScrollContent: {
    paddingLeft: spacing.sm + 5, // Выравнивание по левому краю заголовка "Диагностика"
    paddingRight: spacing.sm,
    gap: spacing.xxs,
  },
  tabButton: {
    paddingHorizontal: spacing.md - 2,
    paddingVertical: spacing.xs,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#E2E4E9',
    marginRight: spacing.xxs,
  },
  tabButtonActive: {
    backgroundColor: '#191BDF',
    borderColor: '#191BDF',
  },
  tabButtonText: {
    fontSize: 16,
    fontWeight: '400',
    color: '#525866',
  },
  tabButtonTextActive: {
    color: '#FFFFFF',
  },
});
