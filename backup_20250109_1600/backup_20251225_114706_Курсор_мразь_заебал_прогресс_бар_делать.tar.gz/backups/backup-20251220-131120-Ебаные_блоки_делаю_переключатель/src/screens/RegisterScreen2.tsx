import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, StyleSheet, ScrollView, Platform, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Asset } from 'expo-asset';
import { SvgXml } from 'react-native-svg';
import AnimatedPressable from '../components/AnimatedPressable';
import { palette, spacing } from '../styles/theme';

interface RegisterScreen2Props {
  onContinue: () => void;
  onSkip?: () => void;
}

export default function RegisterScreen2({ onContinue, onSkip }: RegisterScreen2Props) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [userIconSvg, setUserIconSvg] = useState<string>('');
  const [emailIconSvg, setEmailIconSvg] = useState<string>('');
  const [logoPlaceholderSvg, setLogoPlaceholderSvg] = useState<string>('');

  useEffect(() => {
    // Загружаем SVG иконку для поля "Названия заведения"
    const loadUserIcon = async () => {
      try {
        const iconAsset = Asset.fromModule(require('../../assets/images/venue-name-icon.svg'));
        await iconAsset.downloadAsync();
        if (iconAsset.localUri) {
          const response = await fetch(iconAsset.localUri);
          const fileContent = await response.text();
          setUserIconSvg(fileContent);
        }
      } catch (error) {
        console.error('Ошибка загрузки SVG иконки пользователя (экран 2):', error);
      }
    };

    // Загружаем SVG иконку для поля "Адрес заведения"
    const loadEmailIcon = async () => {
      try {
        const iconAsset = Asset.fromModule(require('../../assets/images/venue-address-icon.svg'));
        await iconAsset.downloadAsync();
        if (iconAsset.localUri) {
          const response = await fetch(iconAsset.localUri);
          const fileContent = await response.text();
          setEmailIconSvg(fileContent);
        }
      } catch (error) {
        console.error('Ошибка загрузки SVG иконки email (экран 2):', error);
      }
    };

    const loadLogoPlaceholderIcon = async () => {
      try {
        const iconAsset = Asset.fromModule(require('../../assets/images/restaurant-avatar-placeholder.svg'));
        await iconAsset.downloadAsync();
        if (iconAsset.localUri) {
          const response = await fetch(iconAsset.localUri);
          const fileContent = await response.text();
          setLogoPlaceholderSvg(fileContent);
        }
      } catch (error) {
        console.error('Ошибка загрузки SVG заглушки логотипа (экран 2):', error);
      }
    };

    loadUserIcon();
    loadEmailIcon();
    loadLogoPlaceholderIcon();
  }, []);

  return (
    <View style={styles.container}>
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <View>
          {/* Header: Step indicator and Skip button */}
          <View style={styles.header}>
            <View style={styles.stepIndicatorContainer}>
              <Text style={styles.stepIndicator}>2 / 3 ШАГ</Text>
            </View>
            <TouchableOpacity onPress={onSkip || (() => {})} style={styles.skipButton}>
              <Text style={styles.skipButtonText}>Пропустить</Text>
            </TouchableOpacity>
          </View>

          {/* Title */}
          <Text style={styles.title}>Данные о вашем{'\n'}ресторане</Text>

          {/* Description */}
          <Text style={styles.description}>
            Укажите заведения, чтобы получить точный анализ по каждому направлению.
          </Text>

          {/* Input Fields (два верхних поля как на первом экране) */}
          <View style={styles.inputsContainer}>
            {/* Названия заведения */}
            <View style={styles.inputWrapper}>
              <Text style={styles.inputLabel}>Названия заведения</Text>
              <View style={styles.inputContainer}>
                {userIconSvg ? (
                  <View style={styles.inputIcon}>
                    <SvgXml xml={userIconSvg} width={20} height={20} />
                  </View>
                ) : (
                  <Ionicons name="person-outline" size={20} color={palette.gray400} style={styles.inputIcon} />
                )}
                <TextInput
                  style={styles.input}
                  placeholder="Суши-бар"
                  placeholderTextColor={palette.gray400}
                  value={name}
                  onChangeText={setName}
                />
              </View>
            </View>

            {/* Адрес заведения */}
            <View style={styles.inputWrapper}>
              <View style={styles.addressLabelRow}>
                <Text style={styles.inputLabel}>Адрес заведения</Text>
                <Text style={styles.mapLinkText}>Указать на карте</Text>
              </View>
              <View style={styles.inputContainer}>
                {emailIconSvg ? (
                  <View style={styles.inputIcon}>
                    <SvgXml xml={emailIconSvg} width={20} height={20} />
                  </View>
                ) : (
                  <Ionicons name="location-outline" size={20} color={palette.gray400} style={styles.inputIcon} />
                )}
                <TextInput
                  style={styles.input}
                  placeholder="Москва, ул. Пушкина, 1А"
                  placeholderTextColor={palette.gray400}
                  value={email}
                  onChangeText={setEmail}
                  keyboardType="email-address"
                  autoCapitalize="none"
                />
              </View>
            </View>
          </View>

          {/* Logo block (как на скрине под вторым полем) */}
          <View style={styles.logoSection}>
            <View style={styles.logoPreview}>
              {logoPlaceholderSvg ? (
                <SvgXml xml={logoPlaceholderSvg} width={50} height={50} />
              ) : (
                <Ionicons name="image-outline" size={30} color={palette.gray400} />
              )}
            </View>
            <View style={styles.logoTextContainer}>
              <Text style={styles.logoTitle}>Логотип</Text>
              <Text style={styles.logoSubtitle}>200x200px, png / jpg</Text>
            </View>
            <TouchableOpacity style={styles.logoUploadButton} activeOpacity={0.8}>
              <Text style={styles.logoUploadButtonText}>Загрузить</Text>
            </TouchableOpacity>
          </View>

          {/* Серая полоса под логотипом, как на дашборде */}
          <View style={styles.logoDivider} />

          {/* "+ Добавить еще ресторан" под серой линией */}
          <View style={styles.addRestaurantRow}>
            <Text style={styles.addRestaurantPlus}>+</Text>
            <Text style={styles.addRestaurantText}>Добавить еще ресторан</Text>
          </View>
        </View>

        {/* Кнопка "Продолжить" внизу экрана, как на первом экране регистрации */}
        <AnimatedPressable
          style={styles.continueButton}
          onPress={onContinue}
        >
          <Text style={styles.continueButtonText}>Продолжить</Text>
        </AnimatedPressable>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: palette.background,
  },
  scrollContent: {
    flexGrow: 1,
    paddingHorizontal: spacing.md,
    paddingTop: Platform.OS === 'ios' ? 60 : 40,
    paddingBottom: spacing.xl,
    justifyContent: 'space-between',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.xl,
    position: 'relative',
  },
  stepIndicatorContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 1,
  },
  stepIndicator: {
    fontSize: 14,
    fontWeight: '600',
    color: 'rgba(10, 13, 20, 0.5)',
    fontFamily: 'Manrope-SemiBold',
    textAlign: 'center',
    letterSpacing: 0.5,
  },
  skipButton: {
    paddingVertical: spacing.xs,
    paddingLeft: spacing.sm,
    paddingRight: 0,
    height: 'auto',
    marginLeft: 'auto', // Выравнивание справа
    zIndex: 2,
  },
  skipButtonText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#191BDF',
    fontFamily: 'Manrope-Medium',
    letterSpacing: 0.5,
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: '#0A0D14',
    fontFamily: 'Manrope-Bold',
    marginTop: -20,
    marginBottom: spacing.sm,
    lineHeight: 36,
    textAlign: 'center',
  },
  description: {
    fontSize: 16,
    fontWeight: '500',
    color: 'rgba(10, 13, 20, 0.8)',
    fontFamily: 'Manrope-Medium',
    marginBottom: spacing.xl,
    lineHeight: 24,
    textAlign: 'center',
  },
  inputsContainer: {
    marginBottom: spacing.lg,
  },
  inputWrapper: {
    marginBottom: spacing.lg,
  },
  addressLabelRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '100%',
    marginBottom: spacing.xs,
  },
  inputLabel: {
    fontSize: 15,
    fontWeight: '600',
    color: '#0A0D14',
    fontFamily: 'Manrope-SemiBold',
    marginBottom: 0,
  },
  mapLinkText: {
    fontSize: 13,
    fontWeight: '500',
    color: '#191BDF',
    fontFamily: 'Manrope-Medium',
    letterSpacing: 0.5,
    paddingRight: 0,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: palette.white,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#E2E4E9',
    paddingHorizontal: spacing.md,
    height: 56,
  },
  inputIcon: {
    marginRight: spacing.sm,
  },
  input: {
    flex: 1,
    fontSize: 16,
    fontWeight: '500',
    color: '#3C4159',
    fontFamily: 'Manrope-Medium',
    padding: 0,
    includeFontPadding: false,
    textAlignVertical: 'center',
  },
  logoSection: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 0, // чтобы иконка и контент выровнялись по левому краю полей регистрации
    paddingVertical: spacing.md,
    marginTop: spacing.lg - 57, // Поднято ещё на 7 пикселей
  },
  logoPreview: {
    width: 56,
    height: 56,
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: spacing.md,
  },
  logoTextContainer: {
    flex: 1,
  },
  logoTitle: {
    fontSize: 17, // на 2 больше, чем у заголовка полей (15)
    fontWeight: '600', // как у заголовков полей регистрации
    color: '#0A0D14', // как у заголовков полей регистрации
    fontFamily: 'Manrope-SemiBold',
    marginBottom: 2, // уменьшен отступ, чтобы подпись подойти ближе к заголовку
  },
  logoSubtitle: {
    fontSize: 14, // на 2 меньше, чем было
    fontWeight: '500', // как у подзаголовка
    color: '#868C98', // как иконка в поле "Адрес заведения"
    fontFamily: 'Manrope-Medium',
    lineHeight: 20,
  },
  logoUploadButton: {
    paddingHorizontal: spacing.md,
    height: 40,
    borderRadius: 12, // как у полей регистрации
    borderWidth: 1,
    borderColor: '#E2E4E9', // как у полей регистрации
    backgroundColor: palette.white, // как у полей регистрации
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoUploadButtonText: {
    fontSize: 16, // как у подзаголовка
    fontWeight: '500', // как у подзаголовка
    color: '#6B7280', // немного темнее подписи под логотипом
    fontFamily: 'Manrope-Medium',
    lineHeight: 24,
  },
  logoDivider: {
    height: 1,
    backgroundColor: '#E2E4E9', // как тонкая серая полоса на дашборде
    marginTop: spacing.md, // отступ вниз от логотипа
    alignSelf: 'stretch', // ширина как у полей регистрации (учитывая paddingHorizontal scrollContent)
  },
  addRestaurantRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: spacing.md + 5, // опущено на 5 пикселей ниже линии
  },
  addRestaurantPlus: {
    fontSize: 20, // на 1 больше, чем текст (19)
    fontWeight: '500',
    color: '#0A0D14',
    fontFamily: 'Manrope-Bold',
    marginRight: -2, // промежуток с текстом
    transform: [{ translateX: -6 }], // сдвиг плюса влево на 6 пикселей
  },
  addRestaurantText: {
    fontSize: 19, // как было
    fontWeight: '500', // как было
    color: '#0A0D14', // как у "Адрес заведения"
    fontFamily: 'Manrope-Bold',
    textAlign: 'center',
  },
  continueButton: {
    backgroundColor: '#191BDF', // Стили как у кнопки "План улучшений"
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    borderRadius: 99,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.md,
  },
  continueButtonText: {
    fontSize: 17, // Стили как у кнопки "План улучшений"
    fontWeight: '300',
    color: '#EBF1FF',
  },
});

