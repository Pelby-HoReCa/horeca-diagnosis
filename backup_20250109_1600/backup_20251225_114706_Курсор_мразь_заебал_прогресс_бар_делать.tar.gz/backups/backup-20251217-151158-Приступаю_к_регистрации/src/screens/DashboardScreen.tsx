import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect } from '@react-navigation/native';
import { Asset } from 'expo-asset';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Image, ImageBackground, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SvgXml } from 'react-native-svg';
import AnimatedPressable from '../components/AnimatedPressable';
import BlockGauge from '../components/BlockGauge';
import { DEFAULT_BLOCKS, DiagnosisBlock } from '../data/diagnosisBlocks';
import { palette, radii, spacing } from '../styles/theme';
import { getTasksByBlock, Task } from '../utils/recommendationEngine';
import {
    getCurrentUserId,
    loadUserBlocks,
    loadUserDashboardData,
    loadUserQuestionnaire,
    loadUserTasks,
    saveUserDashboardData
} from '../utils/userDataStorage';

const COLORS = {
  gray: palette.gray200,
  darkGray: palette.gray600,
  blue: palette.primaryBlue,
  orange: palette.primaryOrange,
  green: palette.success,
  red: palette.error,
  white: palette.white,
};

// Фирменные цвета
interface Comparison {
  previous: number | null; // null означает, что это первое прохождение
  current: number;
  change?: number; // Изменение в процентах (положительное = рост, отрицательное = падение)
}

export default function DashboardScreen({ navigation }: any) {
  const [restaurantName, setRestaurantName] = useState('Проект');
  const [city, setCity] = useState<string>('');
  const [projectAvatarUri, setProjectAvatarUri] = useState<string | null>(null);
  const [blockResults, setBlockResults] = useState<DiagnosisBlock[]>([]);
  const [comparison, setComparison] = useState<Comparison>({ previous: null, current: 0 });
  const [overallEfficiency, setOverallEfficiency] = useState<number>(0);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [allTasksCount, setAllTasksCount] = useState(0);
  const [tasksByBlock, setTasksByBlock] = useState<Record<string, { tasks: Task[], completed: number, total: number }>>({});
  const [cityIconSvg, setCityIconSvg] = useState<string>('');
  const [helpButtonIconSvg, setHelpButtonIconSvg] = useState<string>('');
  const [infoIconSvg, setInfoIconSvg] = useState<string>('');
  const [refreshIconSvg, setRefreshIconSvg] = useState<string>('');
  const [addIconSvg, setAddIconSvg] = useState<string>('');
  const [businessAssessmentIconSvg, setBusinessAssessmentIconSvg] = useState<string>('');
  const [coinsIconSvg, setCoinsIconSvg] = useState<string>('');
  const [colorsIconSvg, setColorsIconSvg] = useState<string>('');
  const [chartBarLineIconSvg, setChartBarLineIconSvg] = useState<string>('');
  const [fileIconSvg, setFileIconSvg] = useState<string>('');
  const [marketingIconSvg, setMarketingIconSvg] = useState<string>('');
  const [computerSettingsIconSvg, setComputerSettingsIconSvg] = useState<string>('');
  const [userMultipleIconSvg, setUserMultipleIconSvg] = useState<string>('');
  const [dishWasherIconSvg, setDishWasherIconSvg] = useState<string>('');
  const [legalDocumentIconSvg, setLegalDocumentIconSvg] = useState<string>('');
  const [chartIncreaseIconSvg, setChartIncreaseIconSvg] = useState<string>('');
  const [showScrollButton, setShowScrollButton] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const scrollViewRef = useRef<ScrollView>(null);

  // Данные для отображения изменения эффективности в "Прошлая диагностика"
  const hasPreviousResult = comparison.previous !== null && comparison.previous !== undefined;
  const hasCurrentResult = comparison.current !== null && comparison.current !== undefined;
  const changeDelta = hasPreviousResult && hasCurrentResult
    ? (comparison.current ?? 0) - (comparison.previous ?? 0)
    : 0;
  const changeColor =
    hasPreviousResult && hasCurrentResult
      ? changeDelta < 0
        ? '#DF1C41' // хуже
        : changeDelta > 0
          ? '#176448' // лучше
          : '#525866' // без изменений
      : '#525866'; // нет данных
  const changeArrow =
    hasPreviousResult && hasCurrentResult
      ? changeDelta < 0
        ? 'arrow-down'
        : 'arrow-up'
      : 'arrow-up';
  const changeDisplayValue =
    hasPreviousResult && hasCurrentResult
      ? Math.abs(changeDelta)
      : 0;

  // Цвета для зеленого/желтого/красного/серого кружка "Прошлая диагностика"
  const getDiagnosisBadgeColors = (value: number) => {
    if (value === 0 || value === undefined || value === null) {
      return { bg: '#F6F8FA', text: '#525866' }; // серый
    }
    if (value >= 78) return { bg: '#CBF5E5', text: '#176448' }; // зеленый
    if (value >= 60) return { bg: '#FFAD1F', text: '#0A0D14' }; // желтый
    if (value >= 38) return { bg: '#FFDAC2', text: '#6E330C' }; // оранжевый (четвертый цвет)
    return { bg: '#F8C9D2', text: '#710E21' }; // красный фон (по запросу), текст требуемого цвета
  };
  // Текущее значение для кружка — берём актуальную общую эффективность (обновляется после каждого пройденного блока)
  const currentBadgeValue = overallEfficiency ?? 0;
  const currentBadgeColors = getDiagnosisBadgeColors(currentBadgeValue);

  // Функция для вычисления общей эффективности всех пройденных блоков
  const calculateOverallEfficiency = (blocks: DiagnosisBlock[]): number => {
    const completedBlocks = blocks.filter(b => b.completed && b.efficiency !== undefined);
    if (completedBlocks.length === 0) return 0;
    return Math.round(
      completedBlocks.reduce((sum, b) => sum + (b.efficiency || 0), 0) / completedBlocks.length
    );
  };

  useEffect(() => {
    loadDashboardData();
    checkAuthStatus();
    
    // Загружаем SVG иконку для города
    const loadCityIcon = async () => {
      try {
        const iconAsset = Asset.fromModule(require('../../assets/images/arrow-down-city.svg'));
        await iconAsset.downloadAsync();
        if (iconAsset.localUri) {
          const response = await fetch(iconAsset.localUri);
          const fileContent = await response.text();
          setCityIconSvg(fileContent);
        }
      } catch (error) {
        console.error('Ошибка загрузки SVG иконки города:', error);
      }
    };
    
    loadCityIcon();
    
    // Загружаем SVG иконку для кнопки помощи
    const loadHelpButtonIcon = async () => {
      try {
        const iconAsset = Asset.fromModule(require('../../assets/images/help-button-icon.svg'));
        await iconAsset.downloadAsync();
        if (iconAsset.localUri) {
          const response = await fetch(iconAsset.localUri);
          const fileContent = await response.text();
          setHelpButtonIconSvg(fileContent);
        }
      } catch (error) {
        console.error('Ошибка загрузки SVG иконки кнопки помощи:', error);
      }
    };
    
    loadHelpButtonIcon();
    
    // Загружаем SVG иконки для секции "Общая эффективность"
    const loadEfficiencyIcons = async () => {
      try {
        // Иконка информации
        const infoAsset = Asset.fromModule(require('../../assets/images/information-line.svg'));
        await infoAsset.downloadAsync();
        if (infoAsset.localUri) {
          const response = await fetch(infoAsset.localUri);
          const fileContent = await response.text();
          setInfoIconSvg(fileContent);
        }
        
        // Иконка обновления
        const refreshAsset = Asset.fromModule(require('../../assets/images/refresh-icon.svg'));
        await refreshAsset.downloadAsync();
        if (refreshAsset.localUri) {
          const response = await fetch(refreshAsset.localUri);
          const fileContent = await response.text();
          setRefreshIconSvg(fileContent);
        }
        
        // Иконка добавления
        const addAsset = Asset.fromModule(require('../../assets/images/add-icon.svg'));
        await addAsset.downloadAsync();
        if (addAsset.localUri) {
          const response = await fetch(addAsset.localUri);
          const fileContent = await response.text();
          setAddIconSvg(fileContent);
        }
        
        // Иконка для "Оценка бизнес-направлений"
        const businessAssessmentAsset = Asset.fromModule(require('../../assets/images/business-assessment-icon.svg'));
        await businessAssessmentAsset.downloadAsync();
        if (businessAssessmentAsset.localUri) {
          const response = await fetch(businessAssessmentAsset.localUri);
          const fileContent = await response.text();
          setBusinessAssessmentIconSvg(fileContent);
        }
        
        // Иконка монет для карточки "Финансы и бухгалтерия"
        const coinsAsset = Asset.fromModule(require('../../assets/images/coins-icon.svg'));
        await coinsAsset.downloadAsync();
        if (coinsAsset.localUri) {
          const response = await fetch(coinsAsset.localUri);
          const fileContent = await response.text();
          setCoinsIconSvg(fileContent);
        }
        
        // Иконка colors для карточки "Концепция и позиционирование"
        const colorsAsset = Asset.fromModule(require('../../assets/images/colors-icon.svg'));
        await colorsAsset.downloadAsync();
        if (colorsAsset.localUri) {
          const response = await fetch(colorsAsset.localUri);
          const fileContent = await response.text();
          setColorsIconSvg(fileContent);
        }
        
        // Иконка chart-bar-line для карточки "Управление и организация"
        const chartBarLineAsset = Asset.fromModule(require('../../assets/images/chart-bar-line-icon.svg'));
        await chartBarLineAsset.downloadAsync();
        if (chartBarLineAsset.localUri) {
          const response = await fetch(chartBarLineAsset.localUri);
          const fileContent = await response.text();
          setChartBarLineIconSvg(fileContent);
        }
        
        // Иконка file для карточки "Продуктовая стратегия"
        const fileAsset = Asset.fromModule(require('../../assets/images/file-icon.svg'));
        await fileAsset.downloadAsync();
        if (fileAsset.localUri) {
          const response = await fetch(fileAsset.localUri);
          const fileContent = await response.text();
          setFileIconSvg(fileContent);
        }
        
        // Иконка marketing для карточки "Маркетинг и продажи"
        const marketingAsset = Asset.fromModule(require('../../assets/images/marketing-icon.svg'));
        await marketingAsset.downloadAsync();
        if (marketingAsset.localUri) {
          const response = await fetch(marketingAsset.localUri);
          const fileContent = await response.text();
          setMarketingIconSvg(fileContent);
        }
        
        // Иконка computer-settings для карточки "Операционная деятельность"
        const computerSettingsAsset = Asset.fromModule(require('../../assets/images/computer-settings-icon.svg'));
        await computerSettingsAsset.downloadAsync();
        if (computerSettingsAsset.localUri) {
          const response = await fetch(computerSettingsAsset.localUri);
          const fileContent = await response.text();
          setComputerSettingsIconSvg(fileContent);
        }
        
        // Иконка user-multiple для карточки "Клиентский опыт"
        const userMultipleAsset = Asset.fromModule(require('../../assets/images/user-multiple-icon.svg'));
        await userMultipleAsset.downloadAsync();
        if (userMultipleAsset.localUri) {
          const response = await fetch(userMultipleAsset.localUri);
          const fileContent = await response.text();
          setUserMultipleIconSvg(fileContent);
        }
        
        // Иконка dish-washer для карточки "Инфраструктура и оборудование"
        const dishWasherAsset = Asset.fromModule(require('../../assets/images/dish-washer-icon.svg'));
        await dishWasherAsset.downloadAsync();
        if (dishWasherAsset.localUri) {
          const response = await fetch(dishWasherAsset.localUri);
          const fileContent = await response.text();
          setDishWasherIconSvg(fileContent);
        }
        
        // Иконка legal-document для карточки "Риски и нормы"
        const legalDocumentAsset = Asset.fromModule(require('../../assets/images/legal-document-icon.svg'));
        await legalDocumentAsset.downloadAsync();
        if (legalDocumentAsset.localUri) {
          const response = await fetch(legalDocumentAsset.localUri);
          const fileContent = await response.text();
          setLegalDocumentIconSvg(fileContent);
        }
        
        // Иконка chart-increase для карточки "Стратегия развития"
        const chartIncreaseAsset = Asset.fromModule(require('../../assets/images/chart-increase-icon.svg'));
        await chartIncreaseAsset.downloadAsync();
        if (chartIncreaseAsset.localUri) {
          const response = await fetch(chartIncreaseAsset.localUri);
          const fileContent = await response.text();
          setChartIncreaseIconSvg(fileContent);
        }
      } catch (error) {
        console.error('Ошибка загрузки SVG иконок эффективности:', error);
      }
    };
    
    loadEfficiencyIcons();
  }, []);

  const checkAuthStatus = async () => {
    try {
      const authStatus = await AsyncStorage.getItem('isAuthenticated');
      setIsAuthenticated(authStatus === 'true');
    } catch (error) {
      console.error('Ошибка проверки авторизации:', error);
      setIsAuthenticated(false);
    }
  };

  // Обновляем данные при возврате на экран
  useFocusEffect(
    useCallback(() => {
      console.log('Дашборд получил фокус, обновляем данные...');
      loadDashboardDataWithoutClearing();
    }, [])
  );

  const loadDashboardData = async () => {
    try {
      console.log('Загружаем данные дашборда...');
      
      const userId = await getCurrentUserId();
      
      // Загружаем название ресторана и город из данных пользователя
      if (userId) {
        const questionnaireData = await loadUserQuestionnaire(userId);
        if (questionnaireData && questionnaireData.restaurantName && questionnaireData.restaurantName.trim()) {
          setRestaurantName(questionnaireData.restaurantName);
        } else {
          setRestaurantName('Проект');
        }
        
        // Загружаем город
        if (questionnaireData && questionnaireData.city) {
          setCity(questionnaireData.city);
        }
      } else {
        setRestaurantName('Проект');
      }
      
      // Загружаем аватар компании
      const savedProjectAvatar = await AsyncStorage.getItem('projectAvatar');
      if (savedProjectAvatar) {
        setProjectAvatarUri(savedProjectAvatar);
      }
      
      // Загружаем существующие данные
      let storedBlocks: DiagnosisBlock[] | null = null;
      let storedTasks: Task[] = [];
      
      if (userId) {
        storedBlocks = await loadUserBlocks(userId);
        storedTasks = await loadUserTasks(userId);
      } else {
        // Fallback к глобальным данным
        const blocksJson = await AsyncStorage.getItem('diagnosisBlocks');
        const tasksJson = await AsyncStorage.getItem('actionPlanTasks');
        if (blocksJson) storedBlocks = JSON.parse(blocksJson);
        if (tasksJson) storedTasks = JSON.parse(tasksJson);
      }
      
      let allBlocksCompleted: string | null = null;
      let storedPrevious: string | null = null;
      let storedCurrent: string | null = null;
      
      if (userId) {
        const dashboardData = await loadUserDashboardData(userId);
        allBlocksCompleted = dashboardData.allBlocksCompleted;
        storedPrevious = dashboardData.previousResult;
        storedCurrent = dashboardData.currentResult;
      } else {
        // Fallback к глобальным данным
        allBlocksCompleted = await AsyncStorage.getItem('dashboardAllBlocksCompleted');
        storedPrevious = await AsyncStorage.getItem('dashboardPreviousResult');
        storedCurrent = await AsyncStorage.getItem('dashboardCurrentResult');
      }
      
      if (storedBlocks) {
        const blocks = Array.isArray(storedBlocks) ? storedBlocks : JSON.parse(storedBlocks);
        // Объединяем загруженные блоки с дефолтными, чтобы показать все блоки
        const allBlocks = DEFAULT_BLOCKS.map(defaultBlock => {
          const foundBlock = blocks.find((b: DiagnosisBlock) => b.id === defaultBlock.id);
          if (foundBlock) {
            // Если блок найден, используем его данные (включая efficiency и completed)
            return {
              ...defaultBlock,
              ...foundBlock,
              // Сохраняем title и description из DEFAULT_BLOCKS
              title: defaultBlock.title,
              description: defaultBlock.description,
            };
          }
          return defaultBlock;
        });
        setBlockResults(allBlocks);
        setOverallEfficiency(calculateOverallEfficiency(allBlocks));
        console.log('Загружены блоки для дашборда:', allBlocks.length);
        
        // Проверяем, все ли блоки завершены
        const completedBlocks = allBlocks.filter(b => b.completed && b.efficiency !== undefined);
        const allCompleted = completedBlocks.length === DEFAULT_BLOCKS.length;
        
        if (allCompleted && completedBlocks.length > 0) {
          // Рассчитываем среднюю эффективность по всем блокам
          const avgEfficiency = Math.round(
            completedBlocks.reduce((sum, b) => sum + (b.efficiency || 0), 0) / completedBlocks.length
          );
          
          const wasAllCompleted = allBlocksCompleted === 'true';
          const previousValue = storedPrevious ? parseInt(storedPrevious, 10) : null;
          const currentValue = storedCurrent ? parseInt(storedCurrent, 10) : 0;
          
          if (!wasAllCompleted) {
            // Первое прохождение всех блоков - сохраняем только ТЕКУЩИЙ, ПРЕДЫДУЩИЙ не сохраняем
            if (userId) {
              await saveUserDashboardData(userId, {
                allBlocksCompleted: 'true',
                currentResult: avgEfficiency.toString(),
                // previousResult не сохраняем при первом прохождении
              });
            } else {
              await AsyncStorage.setItem('dashboardAllBlocksCompleted', 'true');
              await AsyncStorage.setItem('dashboardCurrentResult', avgEfficiency.toString());
              // previousResult не сохраняем при первом прохождении
            }
            setComparison({ previous: null, current: avgEfficiency, change: undefined });
          } else {
            // Последующие прохождения - проверяем, изменился ли результат
            if (avgEfficiency !== currentValue) {
              // Результат изменился - обновляем ПРЕДЫДУЩИЙ и ТЕКУЩИЙ
              const newPrevious = currentValue;
              const newCurrent = avgEfficiency;
              const change = newCurrent - newPrevious;
              
              if (userId) {
                await saveUserDashboardData(userId, {
                  previousResult: newPrevious.toString(),
                  currentResult: newCurrent.toString(),
                });
              } else {
                await AsyncStorage.setItem('dashboardPreviousResult', newPrevious.toString());
                await AsyncStorage.setItem('dashboardCurrentResult', newCurrent.toString());
              }
              setComparison({ previous: newPrevious, current: newCurrent, change });
            } else {
              // Результат не изменился - используем сохраненные значения
              const change = previousValue !== null && currentValue !== previousValue ? currentValue - previousValue : undefined;
              setComparison({ previous: previousValue, current: currentValue, change });
            }
          }
        } else {
          // Не все блоки завершены - ПРЕДЫДУЩИЙ = null, ТЕКУЩИЙ = среднее по завершенным блокам (или 0)
          const avgEfficiency = completedBlocks.length > 0 
            ? Math.round(completedBlocks.reduce((sum, b) => sum + (b.efficiency || 0), 0) / completedBlocks.length)
            : 0;
          setComparison({ previous: null, current: avgEfficiency, change: undefined });
        }
      } else {
        // Если блоков нет, показываем дефолтные
        setBlockResults(DEFAULT_BLOCKS);
        setOverallEfficiency(0);
        setComparison({ previous: null, current: 0, change: undefined });
        console.log('Блоков в хранилище нет, показываем дефолтные');
      }
      
      if (storedTasks && storedTasks.length > 0) {
        // Показываем только первые 3 задачи для списка
        setTasks(storedTasks.slice(0, 3));
        // Сохраняем общее количество задач для метрики
        setAllTasksCount(storedTasks.length);
        // Группируем задачи по блокам
        const groupedTasks = getTasksByBlock(storedTasks);
        setTasksByBlock(groupedTasks);
        console.log('Загружены задачи для дашборда:', storedTasks.length);
      } else {
        setTasks([]);
        setAllTasksCount(0);
        setTasksByBlock({});
        console.log('Задач для дашборда нет');
      }
      
    } catch (error) {
      console.error('Ошибка загрузки данных:', error);
      setTasks([]);
      setBlockResults(DEFAULT_BLOCKS);
      setComparison({ previous: 0, current: 0, change: 0 });
      setOverallEfficiency(0);
    }
  };

  const loadDashboardDataWithoutClearing = async () => {
    try {
      console.log('Загружаем данные дашборда без очистки...');
      
      const userId = await getCurrentUserId();
      
      // Загружаем название ресторана и город из данных пользователя
      if (userId) {
        const questionnaireData = await loadUserQuestionnaire(userId);
        if (questionnaireData && questionnaireData.restaurantName && questionnaireData.restaurantName.trim()) {
          setRestaurantName(questionnaireData.restaurantName);
        } else {
          setRestaurantName('Проект');
        }
        
        // Загружаем город
        if (questionnaireData && questionnaireData.city) {
          setCity(questionnaireData.city);
        }
      } else {
        setRestaurantName('Проект');
      }
      
      // Загружаем аватар компании
      const savedProjectAvatar = await AsyncStorage.getItem('projectAvatar');
      if (savedProjectAvatar) {
        setProjectAvatarUri(savedProjectAvatar);
      }
      
      // Загружаем существующие данные
      let storedBlocks: DiagnosisBlock[] | null = null;
      let storedTasks: Task[] = [];
      
      if (userId) {
        storedBlocks = await loadUserBlocks(userId);
        storedTasks = await loadUserTasks(userId);
      } else {
        // Fallback к глобальным данным
        const blocksJson = await AsyncStorage.getItem('diagnosisBlocks');
        const tasksJson = await AsyncStorage.getItem('actionPlanTasks');
        if (blocksJson) storedBlocks = JSON.parse(blocksJson);
        if (tasksJson) storedTasks = JSON.parse(tasksJson);
      }
      let allBlocksCompleted: string | null = null;
      let storedPrevious: string | null = null;
      let storedCurrent: string | null = null;
      
      if (userId) {
        const dashboardData = await loadUserDashboardData(userId);
        allBlocksCompleted = dashboardData.allBlocksCompleted;
        storedPrevious = dashboardData.previousResult;
        storedCurrent = dashboardData.currentResult;
      } else {
        allBlocksCompleted = await AsyncStorage.getItem('dashboardAllBlocksCompleted');
        storedPrevious = await AsyncStorage.getItem('dashboardPreviousResult');
        storedCurrent = await AsyncStorage.getItem('dashboardCurrentResult');
      }
      
      if (storedBlocks) {
        const blocks = Array.isArray(storedBlocks) ? storedBlocks : JSON.parse(storedBlocks);
        // Объединяем загруженные блоки с дефолтными, чтобы показать все блоки
        const allBlocks = DEFAULT_BLOCKS.map(defaultBlock => {
          const foundBlock = blocks.find((b: DiagnosisBlock) => b.id === defaultBlock.id);
          if (foundBlock) {
            // Если блок найден, используем его данные (включая efficiency и completed)
            return {
              ...defaultBlock,
              ...foundBlock,
              // Сохраняем title и description из DEFAULT_BLOCKS
              title: defaultBlock.title,
              description: defaultBlock.description,
            };
          }
          return defaultBlock;
        });
        setBlockResults(allBlocks);
        setOverallEfficiency(calculateOverallEfficiency(allBlocks));
        console.log('Загружены блоки для дашборда:', allBlocks.length);
        
        // Проверяем, все ли блоки завершены
        const completedBlocks = allBlocks.filter(b => b.completed && b.efficiency !== undefined);
        const allCompleted = completedBlocks.length === DEFAULT_BLOCKS.length;
        
        if (allCompleted && completedBlocks.length > 0) {
          // Рассчитываем среднюю эффективность по всем блокам
          const avgEfficiency = Math.round(
            completedBlocks.reduce((sum, b) => sum + (b.efficiency || 0), 0) / completedBlocks.length
          );
          
          const wasAllCompleted = allBlocksCompleted === 'true';
          const previousValue = storedPrevious ? parseInt(storedPrevious, 10) : null;
          const currentValue = storedCurrent ? parseInt(storedCurrent, 10) : 0;
          
          if (!wasAllCompleted) {
            // Первое прохождение всех блоков - сохраняем только ТЕКУЩИЙ, ПРЕДЫДУЩИЙ не сохраняем
            if (userId) {
              await saveUserDashboardData(userId, {
                allBlocksCompleted: 'true',
                currentResult: avgEfficiency.toString(),
                // previousResult не сохраняем при первом прохождении
              });
            } else {
              await AsyncStorage.setItem('dashboardAllBlocksCompleted', 'true');
              await AsyncStorage.setItem('dashboardCurrentResult', avgEfficiency.toString());
              // previousResult не сохраняем при первом прохождении
            }
            setComparison({ previous: null, current: avgEfficiency, change: undefined });
          } else {
            // Последующие прохождения - проверяем, изменился ли результат
            if (avgEfficiency !== currentValue) {
              // Результат изменился - обновляем ПРЕДЫДУЩИЙ и ТЕКУЩИЙ
              const newPrevious = currentValue;
              const newCurrent = avgEfficiency;
              const change = newCurrent - newPrevious;
              
              if (userId) {
                await saveUserDashboardData(userId, {
                  previousResult: newPrevious.toString(),
                  currentResult: newCurrent.toString(),
                });
              } else {
                await AsyncStorage.setItem('dashboardPreviousResult', newPrevious.toString());
                await AsyncStorage.setItem('dashboardCurrentResult', newCurrent.toString());
              }
              setComparison({ previous: newPrevious, current: newCurrent, change });
            } else {
              // Результат не изменился - используем сохраненные значения
              const change = previousValue !== null && currentValue !== previousValue ? currentValue - previousValue : undefined;
              setComparison({ previous: previousValue, current: currentValue, change });
            }
          }
        } else {
          // Не все блоки завершены - ПРЕДЫДУЩИЙ = null, ТЕКУЩИЙ = среднее по завершенным блокам (или 0)
          const avgEfficiency = completedBlocks.length > 0 
            ? Math.round(completedBlocks.reduce((sum, b) => sum + (b.efficiency || 0), 0) / completedBlocks.length)
            : 0;
          setComparison({ previous: null, current: avgEfficiency, change: undefined });
        }
      } else {
        // Если блоков нет, показываем дефолтные
        setBlockResults(DEFAULT_BLOCKS);
        setOverallEfficiency(0);
        setComparison({ previous: null, current: 0, change: undefined });
        console.log('Блоков в хранилище нет, показываем дефолтные');
      }

      // Загружаем задачи
      if (storedTasks && storedTasks.length > 0) {
        setTasks(storedTasks.slice(0, 3)); // Показываем только первые 3 задачи
        setAllTasksCount(storedTasks.length); // Сохраняем общее количество задач
        // Группируем задачи по блокам
        const groupedTasks = getTasksByBlock(storedTasks);
        setTasksByBlock(groupedTasks);
        console.log('Загружены задачи для дашборда:', storedTasks.length);
      } else {
        setTasks([]);
        setAllTasksCount(0);
        setTasksByBlock({});
        console.log('Задач для дашборда нет');
      }
      
    } catch (error) {
      console.error('Ошибка загрузки данных дашборда:', error);
    }
  };

  // Функция для получения иконки блока
  const getBlockIcon = (blockId: string): keyof typeof Ionicons.glyphMap => {
    const iconMap: Record<string, keyof typeof Ionicons.glyphMap> = {
      'concept': 'bulb-outline',
      'finance': 'cash-outline',
      'management': 'people-outline',
      'menu': 'restaurant-outline',
      'marketing': 'megaphone-outline',
      'operations': 'settings-outline',
      'client_experience': 'happy-outline',
      'infrastructure': 'build-outline',
      'risks': 'shield-outline',
      'strategy': 'trending-up-outline',
    };
    return iconMap[blockId] || 'cube-outline';
  };

  const getEfficiencyColor = (efficiency?: number): { bg: string; text: string; border?: string } => {
    if (efficiency === undefined || efficiency === null) {
      return { bg: COLORS.gray, text: COLORS.darkGray };
    }
    
    // Чем ниже эффективность, тем тревожнее цвет
    if (efficiency >= 80) {
      // Высокая эффективность - спокойный зеленоватый
      return { bg: '#E8F5E9', text: COLORS.green, border: '#81C784' };
    } else if (efficiency >= 60) {
      // Средняя эффективность - нейтральный голубоватый
      return { bg: '#E3F2FD', text: COLORS.blue, border: '#64B5F6' };
    } else if (efficiency >= 40) {
      // Низкая эффективность - предупреждающий оранжевый
      return { bg: '#FFF3E0', text: '#F57C00', border: '#FFB74D' };
    } else {
      // Очень низкая эффективность - тревожный красноватый
      return { bg: '#FFEBEE', text: '#D32F2F', border: '#E57373' };
    }
  };


  const scrollToTop = () => {
    scrollViewRef.current?.scrollTo({ y: 0, animated: true });
  };

  const handleScroll = (event: any) => {
    const offsetY = event.nativeEvent.contentOffset.y;
    setShowScrollButton(offsetY > 500);
  };

  return (
    <View style={styles.container}>
      <ScrollView 
        ref={scrollViewRef} 
        style={styles.scrollView}
        onScroll={handleScroll}
        scrollEventThrottle={16}
      >
        {/* Секция профиля проекта */}
        <View style={[styles.section, styles.profileSection]}>
          <View style={styles.profileInfo}>
            {/* Аватар компании */}
            <View style={styles.avatarContainer}>
              {projectAvatarUri ? (
                <Image source={{ uri: projectAvatarUri }} style={styles.avatarImage} />
              ) : (
                <View style={styles.avatarPlaceholder}>
                  <Ionicons name="business" size={32} color={palette.gray400} />
                </View>
              )}
            </View>
            
            {/* Название и город */}
            <View style={styles.projectInfo}>
              <Text style={styles.projectName}>Проект</Text>
              <View style={styles.cityContainer}>
                <Text style={styles.cityText}>{city || 'город'}</Text>
                {cityIconSvg && (
                  <View style={styles.cityIconContainer}>
                    <SvgXml xml={cityIconSvg} width={16} height={16} />
                  </View>
                )}
              </View>
            </View>
          </View>
          
          {/* Кнопка Помощь PELBY */}
          <AnimatedPressable 
            style={styles.helpButton}
            onPress={() => {
              if (navigation) {
                navigation.navigate('Help');
              }
            }}
          >
            {helpButtonIconSvg ? (
              <View style={styles.helpButtonIconContainer}>
                <SvgXml xml={helpButtonIconSvg} width={18} height={18} />
              </View>
            ) : null}
            <Text style={styles.helpButtonText}>Помощь PELBY</Text>
          </AnimatedPressable>
        </View>

        {/* Секция Общая эффективность */}
        <View style={[styles.section, styles.efficiencySection]}>
          {/* Заголовок с иконками */}
          <View style={styles.efficiencyHeader}>
            <View style={styles.efficiencyTitleContainer}>
              <Text style={styles.efficiencyTitle}>Общая эффективность</Text>
              {infoIconSvg && (
                <AnimatedPressable style={styles.infoIconButton}>
                  <SvgXml xml={infoIconSvg} width={20} height={20} />
                </AnimatedPressable>
              )}
            </View>
            <View style={styles.efficiencyIcons}>
              {refreshIconSvg && (
                <AnimatedPressable style={styles.iconButton}>
                  <SvgXml xml={refreshIconSvg} width={36} height={36} />
                </AnimatedPressable>
              )}
              {addIconSvg && (
                <AnimatedPressable style={styles.iconButton}>
                  <SvgXml xml={addIconSvg} width={36} height={36} />
                </AnimatedPressable>
              )}
            </View>
          </View>

          {/* Серая полоса под заголовком */}
          <View style={styles.efficiencyDivider} />

          {/* Спидометр */}
          <View style={styles.gaugeContainer}>
            <BlockGauge 
              blockResults={blockResults}
              currentValue={overallEfficiency}
            />
          </View>


          {/* Метрики */}
          <View style={styles.metricsContainer}>
            {/* Слабых блоков */}
            <View style={styles.metricItem}>
              <Text style={styles.metricLabel}>Слабых блоков</Text>
              {(() => {
                const weakBlocksCount = blockResults.filter(b => b.completed && b.efficiency !== undefined && b.efficiency < 38).length;
                // Преобразуем количество слабых блоков (0-10) в процент для определения цвета по той же шкале, что в карточках
                // 0 слабых = 100% (все хорошо), 10 слабых = 0% (все плохо)
                // Инвертируем: если 0 слабых блоков, это 100% эффективности, если 10 слабых - 0%
                const efficiencyPercent = weakBlocksCount === 0 ? 100 : Math.max(0, 100 - (weakBlocksCount * 10));
                const weakBlocksColors = getDiagnosisBadgeColors(efficiencyPercent);
                return (
                  <View style={[styles.metricBadge, { backgroundColor: weakBlocksColors.bg, minWidth: 35, paddingHorizontal: 6 }]}>
                    <Text style={[styles.weakBlocksBadgeText, { color: weakBlocksColors.text }]}>
                      {weakBlocksCount}
                    </Text>
                  </View>
                );
              })()}
            </View>
            
            {/* Серая полоса под "Слабых блоков" */}
            <View style={styles.weakBlocksDivider} />

            {/* Прошлая диагностика */}
            <View style={[styles.metricItem, { marginTop: 20 }]}>
              <Text style={styles.metricLabel}>Прошлая диагностика</Text>
              <View style={styles.metricValueRow}>
                <View style={styles.changeIndicator}>
                  {changeDisplayValue !== 0 && (
                    <Text style={[styles.changeText, { color: changeColor, marginRight: 2 }]}>
                      {changeArrow === 'arrow-up' ? '▴' : '▾'}
                    </Text>
                  )}
                  <Text style={[styles.changeText, { color: changeColor }]}>
                    {changeDisplayValue}%
                  </Text>
                </View>
                <View style={[styles.metricBadge, styles.previousDiagnosisBadge, { backgroundColor: currentBadgeColors.bg }]}>
                  <Text style={[styles.previousDiagnosisBadgeText, { color: currentBadgeColors.text }]}>
                    {`${currentBadgeValue}%`}
                  </Text>
                </View>
              </View>
            </View>

            {/* Задач по улучшению */}
            <View style={[styles.metricItem, { marginTop: -3 }]}>
              <Text style={styles.metricLabel}>Задач по улучшению</Text>
              <View style={[styles.metricBadge, styles.tasksBadge]}>
                <Text style={styles.tasksBadgeText}>
                  {allTasksCount}
                </Text>
              </View>
            </View>
          </View>

          {/* Кнопка "План улучшений" */}
          <AnimatedPressable 
            style={[styles.improvementPlanButton, { marginTop: -20 }]}
            onPress={() => navigation.navigate('ActionPlan')}
          >
            <Text style={styles.improvementPlanButtonText}>План улучшений</Text>
          </AnimatedPressable>
        </View>

        {/* Секция Оценка бизнес-направлений */}
        <View style={styles.businessAssessmentTitleContainer}>
          <Text style={styles.businessAssessmentTitle}>Оценка бизнес-направлений</Text>
          {businessAssessmentIconSvg && (
            <View style={styles.businessAssessmentIconContainer}>
              <SvgXml xml={businessAssessmentIconSvg} width={40} height={40} />
            </View>
          )}
        </View>
        {/* Сетка карточек блоков */}
        <View style={styles.blocksGridContainer}>
          <View style={styles.blocksGridNew}>
            {blockResults.map((block) => {
              const efficiency = block.efficiency ?? 0;
              const colors = getEfficiencyColor(block.efficiency);
              const blockTasks = tasksByBlock[block.id] || { total: 0, completed: 0 };
              const iconName = getBlockIcon(block.id);
              
              // Определяем цвет badge по тем же правилам, что и "Прошлая диагностика"
              const blockEfficiencyValue = block.completed && block.efficiency !== undefined ? block.efficiency : 0;
              const blockBadgeColors = getDiagnosisBadgeColors(blockEfficiencyValue);

              return (
                <AnimatedPressable
                  key={block.id}
                  style={styles.businessBlockCard}
                  onPress={() => {
                    if (navigation) {
                      navigation.navigate('BlockDetail', { blockId: block.id });
                    }
                  }}
                >
                  {/* Верх: иконка слева и процент эффективности в badge справа */}
                  <View style={styles.blockCardTopRow}>
                    {/* Иконка в левом верхнем углу */}
                    {block.id === 'finance' && coinsIconSvg && (
                      <View style={styles.blockCardIcon}>
                        <SvgXml xml={coinsIconSvg} width={38} height={38} />
                      </View>
                    )}
                    {block.id === 'concept' && colorsIconSvg && (
                      <View style={styles.blockCardIcon}>
                        <SvgXml xml={colorsIconSvg} width={38} height={38} />
                      </View>
                    )}
                    {block.id === 'management' && chartBarLineIconSvg && (
                      <View style={styles.blockCardIcon}>
                        <SvgXml xml={chartBarLineIconSvg} width={38} height={38} />
                      </View>
                    )}
                    {block.id === 'menu' && fileIconSvg && (
                      <View style={styles.blockCardIcon}>
                        <SvgXml xml={fileIconSvg} width={38} height={38} />
                      </View>
                    )}
                    {block.id === 'marketing' && marketingIconSvg && (
                      <View style={styles.blockCardIcon}>
                        <SvgXml xml={marketingIconSvg} width={38} height={38} />
                      </View>
                    )}
                    {block.id === 'operations' && computerSettingsIconSvg && (
                      <View style={styles.blockCardIcon}>
                        <SvgXml xml={computerSettingsIconSvg} width={38} height={38} />
                      </View>
                    )}
                    {block.id === 'client_experience' && userMultipleIconSvg && (
                      <View style={styles.blockCardIcon}>
                        <SvgXml xml={userMultipleIconSvg} width={38} height={38} />
                      </View>
                    )}
                    {block.id === 'infrastructure' && dishWasherIconSvg && (
                      <View style={styles.blockCardIcon}>
                        <SvgXml xml={dishWasherIconSvg} width={38} height={38} />
                      </View>
                    )}
                    {block.id === 'risks' && legalDocumentIconSvg && (
                      <View style={styles.blockCardIcon}>
                        <SvgXml xml={legalDocumentIconSvg} width={38} height={38} />
                      </View>
                    )}
                    {block.id === 'strategy' && chartIncreaseIconSvg && (
                      <View style={styles.blockCardIcon}>
                        <SvgXml xml={chartIncreaseIconSvg} width={38} height={38} />
                      </View>
                    )}
                    {/* Процент эффективности в badge справа */}
                    <View
                      style={[
                        styles.blockEfficiencyBadge,
                        { backgroundColor: blockBadgeColors.bg },
                      ]}
                    >
                      <Text style={[styles.blockEfficiencyPercent, { color: blockBadgeColors.text }]}>
                        {block.completed && block.efficiency !== undefined ? `${block.efficiency}%` : '0%'}
                      </Text>
                    </View>
                  </View>

                  {/* Низ: заголовок и задачи как единый блок снизу */}
                  <View style={styles.blockTextGroup}>
                    <Text
                      style={styles.blockTitle}
                      numberOfLines={block.id === 'strategy' ? 1 : undefined}
                      ellipsizeMode={block.id === 'strategy' ? 'clip' : 'tail'}
                    >
                      {block.title}
                    </Text>
                    <Text style={styles.blockTasksText}>
                      {(() => {
                        // Если эффективность блока от 90% до 100% включительно - показываем "Все хорошо"
                        if (block.completed && block.efficiency !== undefined && block.efficiency >= 90 && block.efficiency <= 100) {
                          return 'Все хорошо';
                        }
                        // Иначе показываем количество задач
                        const n = blockTasks.total;
                        if (n === 0) return '0 задач';
                        const lastDigit = n % 10;
                        const lastTwoDigits = n % 100;
                        let taskWord = 'задач';
                        if (lastTwoDigits >= 11 && lastTwoDigits <= 14) taskWord = 'задач';
                        else if (lastDigit === 1) taskWord = 'задача';
                        else if (lastDigit >= 2 && lastDigit <= 4) taskWord = 'задачи';
                        return `${n} ${taskWord}`;
                      })()}
                    </Text>
                  </View>
                </AnimatedPressable>
              );
            })}
          </View>
        </View>

        {/* Секция призыва к действию */}
        <View style={[styles.section, styles.ctaSection]}>
          <ImageBackground 
            source={require('../../assets/images/cta-card-background.png')} 
            style={styles.ctaCard}
            imageStyle={styles.ctaCardBackgroundImage}
          >
            <Text style={styles.ctaTitle}>Провалы в эффективности?</Text>
            <Text style={styles.ctaDescription} numberOfLines={1} ellipsizeMode="tail">
              У нас есть решения для всех направлений
            </Text>
            <AnimatedPressable 
              style={styles.ctaButton}
              onPress={() => {
                if (navigation) {
                  navigation.navigate('Help');
                }
              }}
            >
              <Text style={styles.ctaButtonText}>Улучшить эффективность</Text>
            </AnimatedPressable>
          </ImageBackground>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: palette.background,
  },
  scrollView: {
    flex: 1,
  },
  // Секция профиля проекта
  profileSection: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingRight: 0,
    paddingVertical: spacing.md,
    marginTop: spacing.xxl,
    marginBottom: spacing.lg,
    marginRight: spacing.md,
    marginLeft: spacing.sm,
  },
  profileInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    transform: [{ translateY: -2 }],
  },
  avatarContainer: {
    marginRight: 2,
  },
  avatarImage: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: palette.gray100,
  },
  avatarPlaceholder: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: palette.gray100,
    justifyContent: 'center',
    alignItems: 'center',
  },
  projectInfo: {
    flex: 1,
    transform: [{ translateY: -2 }],
  },
  projectName: {
    fontSize: 18,
    fontWeight: '400',
    color: '#0A0D14',
    marginBottom: spacing.xxs,
    marginTop: 0,
    marginLeft: -1,
    transform: [{ translateY: 2 }],
  },
  cityContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  cityText: {
    fontSize: 14,
    color: palette.gray600,
    marginRight: 2,
  },
  cityIconContainer: {
    marginLeft: 2,
    transform: [{ translateY: 1 }],
  },
  helpButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FD680A',
    paddingLeft: 6,
    paddingRight: 6,
    paddingVertical: 6,
    height: 32,
    borderRadius: 999,
    marginLeft: -1,
    transform: [{ translateY: -2 }],
  },
  helpButtonIconContainer: {
    marginRight: 2,
    marginLeft: 0,
  },
  helpButtonText: {
    fontSize: 14,
    fontWeight: '300',
    color: palette.white,
    lineHeight: 16,
    transform: [{ translateY: 0 }, { translateX: -1 }],
  },
  section: {
    marginHorizontal: spacing.md,
    marginBottom: spacing.md,
  },
  // Секция Общая эффективность
  efficiencySection: {
    backgroundColor: palette.white,
    borderRadius: radii.md,
    paddingHorizontal: spacing.md,
    paddingTop: spacing.lg + 20,
    paddingBottom: spacing.md,
    marginBottom: spacing.lg,
    marginTop: -(spacing.md + 15),
    shadowColor: palette.midnightBlue,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 3,
  },
  efficiencyHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: -10,
    marginBottom: spacing.sm,
  },
  efficiencyTitleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  efficiencyTitle: {
    fontSize: 17,
    fontWeight: '400',
    color: '#0A0D14',
    marginRight: 2,
  },
  infoIconButton: {
    marginLeft: 2,
    marginTop: 1,
  },
  efficiencyIcons: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
  },
  iconButton: {
    // Убрали padding, чтобы иконки выравнивались как метрики ниже
  },
  efficiencyDivider: {
    height: 1,
    backgroundColor: '#E2E4E9',
    marginLeft: 5,
    marginRight: 5,
    marginBottom: (spacing.lg - spacing.sm) / 2,
    zIndex: 1,
    position: 'relative',
  },
  weakBlocksDivider: {
    height: 1,
    backgroundColor: '#E2E4E9',
    marginLeft: 0,
    marginRight: 0,
    marginBottom: (spacing.lg - spacing.sm) / 2,
    zIndex: 1,
    position: 'relative',
  },
  gaugeContainer: {
    alignItems: 'center',
    marginTop: spacing.xs,
    marginBottom: spacing.md,
    overflow: 'visible',
    zIndex: 10,
    elevation: 10,
    position: 'relative',
  },
  blocksCountText: {
    fontSize: 14,
    fontWeight: '600',
    color: palette.gray600,
    textAlign: 'center',
    marginTop: spacing.sm,
    marginBottom: spacing.lg,
    letterSpacing: 0.5,
  },
  metricsContainer: {
    marginBottom: spacing.lg,
  },
  metricItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.md,
  },
  metricLabel: {
    fontSize: 16,
    fontWeight: '300',
    color: '#0A0D14',
    flex: 1,
  },
  metricValueRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
  },
  metricBadge: {
    minWidth: 50,
    paddingHorizontal: spacing.sm,
    paddingVertical: 6,
    borderRadius: radii.pill,
    alignItems: 'center',
    justifyContent: 'center',
  },
  weakBlocksBadge: {
    backgroundColor: '#F8C9D2',
    minWidth: 35,
    paddingHorizontal: 6,
  },
  tasksBadge: {
    backgroundColor: '#F6F8FA',
    minWidth: 42,
    paddingHorizontal: 8,
  },
  weakBlocksBadgeText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#710E21',
  },
  previousDiagnosisBadge: {
    backgroundColor: '#CBF5E5',
    minWidth: 55,
    paddingHorizontal: 6,
  },
  previousDiagnosisBadgeText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#176448',
    lineHeight: 16,
    includeFontPadding: false,
    transform: [{ translateX: 5 }],
  },
  tasksBadgeText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#525866',
  },
  changeIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 4,
  },
  changeText: {
    fontSize: 13,
    fontWeight: '500',
    marginLeft: spacing.xs,
    color: '#DF1C41',
  },
  improvementPlanButton: {
    backgroundColor: '#191BDF',
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    borderRadius: 99,
    alignItems: 'center',
    justifyContent: 'center',
  },
  improvementPlanButtonText: {
    fontSize: 17,
    fontWeight: '300',
    color: '#EBF1FF',
  },
  // Секция Оценка бизнес-направлений
  businessAssessmentTitleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: spacing.md - 14,
    marginBottom: spacing.md,
    paddingLeft: spacing.md,
    paddingRight: spacing.md,
  },
  businessAssessmentIconContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  businessAssessmentSection: {
    backgroundColor: palette.white,
    borderRadius: radii.xl,
    padding: spacing.lg,
    marginBottom: spacing.lg,
    marginTop: spacing.md,
    shadowColor: palette.midnightBlue,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 3,
  },
  businessAssessmentHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.lg,
  },
  businessAssessmentTitle: {
    fontSize: 21,
    fontWeight: '400',
    color: '#0A0D14',
  },
  filterButton: {
    padding: spacing.xs,
  },
  blocksGridContainer: {
    paddingHorizontal: spacing.md,
    marginBottom: 3,
  },
  blocksGridNew: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  businessBlockCard: {
    width: 170,
    height: 140,
    backgroundColor: palette.white,
    borderRadius: radii.md,
    paddingTop: spacing.md,
    paddingBottom: spacing.md,
    paddingHorizontal: spacing.xs + 5,
    marginBottom: spacing.md,
    shadowColor: palette.midnightBlue,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
    flexDirection: 'column',
    justifyContent: 'space-between',
  },
  blockCardTopRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 0,
  },
  blockCardIcon: {
    alignItems: 'flex-start',
    justifyContent: 'flex-start',
  },
  blockCardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: spacing.md,
  },
  blockIconContainer: {
    width: 48,
    height: 48,
    justifyContent: 'center',
    alignItems: 'center',
  },
  blockEfficiencyBadge: {
    borderRadius: 99,
    paddingHorizontal: 6,
    paddingVertical: 6,
    minWidth: 55,
    alignItems: 'center',
    justifyContent: 'center',
  },
  blockEfficiencyPercent: {
    fontSize: 13,
    fontWeight: '600',
    lineHeight: 16,
    includeFontPadding: false,
  },
  blockTextGroup: {
    marginTop: 0,
  },
  blockTitle: {
    fontSize: 14,
    fontWeight: '500',
    color: '#0A0D14',
    marginBottom: 2,
    lineHeight: 20,
    flexWrap: 'wrap',
  },
  blockTasksContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
  },
  blockTasksText: {
    fontSize: 14,
    fontWeight: '400',
    color: palette.gray600,
    marginTop: 2,
  },
  // Секция призыва к действию
  ctaSection: {
    marginBottom: spacing.lg,
  },
  ctaCard: {
    borderRadius: radii.md,
    paddingHorizontal: spacing.md,
    paddingTop: spacing.md,
    paddingBottom: spacing.md,
    height: 166,
    overflow: 'hidden',
    shadowColor: palette.midnightBlue,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.15,
    shadowRadius: 16,
    elevation: 6,
  },
  ctaCardBackgroundImage: {
    resizeMode: 'cover',
    transform: [{ translateY: 1 }, { scaleY: 1.03 }],
  },
  ctaTitle: {
    fontSize: 19,
    fontWeight: '400',
    color: '#FFFFFF',
    marginBottom: spacing.sm,
  },
  ctaDescription: {
    fontSize: 16,
    fontWeight: '300',
    color: 'rgba(255, 255, 255, 0.8)',
    lineHeight: 20,
    marginBottom: spacing.lg,
  },
  ctaButton: {
    backgroundColor: '#FD680A',
    borderRadius: 99,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    alignItems: 'center',
    justifyContent: 'center',
  },
  ctaButtonText: {
    fontSize: 17,
    fontWeight: '300',
    color: palette.white,
  },
});
