import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect } from '@react-navigation/native';
import { Asset } from 'expo-asset';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Image, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SvgXml } from 'react-native-svg';
import AnimatedPressable from '../components/AnimatedPressable';
import BlockGauge from '../components/BlockGauge';
import ScrollToTopButton from '../components/ScrollToTopButton';
import { DEFAULT_BLOCKS, DiagnosisBlock } from '../data/diagnosisBlocks';
import { palette, radii, spacing } from '../styles/theme';
import { getTasksByBlock, Task } from '../utils/recommendationEngine';
import {
  getCurrentUserId,
  loadUserBlocks,
  loadUserDashboardData,
  loadUserQuestionnaire,
  loadUserTasks,
  saveUserDashboardData
} from '../utils/userDataStorage';

const COLORS = {
  gray: palette.gray200,
  darkGray: palette.gray600,
  blue: palette.primaryBlue,
  orange: palette.primaryOrange,
  green: palette.success,
  red: palette.error,
  white: palette.white,
};

// Фирменные цвета
interface Comparison {
  previous: number | null; // null означает, что это первое прохождение
  current: number;
  change?: number; // Изменение в процентах (положительное = рост, отрицательное = падение)
}

export default function DashboardScreen({ navigation }: any) {
  const [restaurantName, setRestaurantName] = useState('Проект');
  const [city, setCity] = useState<string>('');
  const [projectAvatarUri, setProjectAvatarUri] = useState<string | null>(null);
  const [blockResults, setBlockResults] = useState<DiagnosisBlock[]>([]);
  const [comparison, setComparison] = useState<Comparison>({ previous: null, current: 0 });
  const [tasks, setTasks] = useState<Task[]>([]);
  const [allTasksCount, setAllTasksCount] = useState(0);
  const [tasksByBlock, setTasksByBlock] = useState<Record<string, { tasks: Task[], completed: number, total: number }>>({});
  const [cityIconSvg, setCityIconSvg] = useState<string>('');
  const [helpButtonIconSvg, setHelpButtonIconSvg] = useState<string>('');
  const [infoIconSvg, setInfoIconSvg] = useState<string>('');
  const [refreshIconSvg, setRefreshIconSvg] = useState<string>('');
  const [addIconSvg, setAddIconSvg] = useState<string>('');
  const [showScrollButton, setShowScrollButton] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const scrollViewRef = useRef<ScrollView>(null);

  useEffect(() => {
    loadDashboardData();
    checkAuthStatus();
    
    // Загружаем SVG иконку для города
    const loadCityIcon = async () => {
      try {
        const iconAsset = Asset.fromModule(require('../../assets/images/arrow-down-city.svg'));
        await iconAsset.downloadAsync();
        if (iconAsset.localUri) {
          const response = await fetch(iconAsset.localUri);
          const fileContent = await response.text();
          setCityIconSvg(fileContent);
        }
      } catch (error) {
        console.error('Ошибка загрузки SVG иконки города:', error);
      }
    };
    
    loadCityIcon();
    
    // Загружаем SVG иконку для кнопки помощи
    const loadHelpButtonIcon = async () => {
      try {
        const iconAsset = Asset.fromModule(require('../../assets/images/help-button-icon.svg'));
        await iconAsset.downloadAsync();
        if (iconAsset.localUri) {
          const response = await fetch(iconAsset.localUri);
          const fileContent = await response.text();
          setHelpButtonIconSvg(fileContent);
        }
      } catch (error) {
        console.error('Ошибка загрузки SVG иконки кнопки помощи:', error);
      }
    };
    
    loadHelpButtonIcon();
    
    // Загружаем SVG иконки для секции "Общая эффективность"
    const loadEfficiencyIcons = async () => {
      try {
        // Иконка информации
        const infoAsset = Asset.fromModule(require('../../assets/images/information-line.svg'));
        await infoAsset.downloadAsync();
        if (infoAsset.localUri) {
          const response = await fetch(infoAsset.localUri);
          const fileContent = await response.text();
          setInfoIconSvg(fileContent);
        }
        
        // Иконка обновления
        const refreshAsset = Asset.fromModule(require('../../assets/images/refresh-icon.svg'));
        await refreshAsset.downloadAsync();
        if (refreshAsset.localUri) {
          const response = await fetch(refreshAsset.localUri);
          const fileContent = await response.text();
          setRefreshIconSvg(fileContent);
        }
        
        // Иконка добавления
        const addAsset = Asset.fromModule(require('../../assets/images/add-icon.svg'));
        await addAsset.downloadAsync();
        if (addAsset.localUri) {
          const response = await fetch(addAsset.localUri);
          const fileContent = await response.text();
          setAddIconSvg(fileContent);
        }
      } catch (error) {
        console.error('Ошибка загрузки SVG иконок эффективности:', error);
      }
    };
    
    loadEfficiencyIcons();
  }, []);

  const checkAuthStatus = async () => {
    try {
      const authStatus = await AsyncStorage.getItem('isAuthenticated');
      setIsAuthenticated(authStatus === 'true');
    } catch (error) {
      console.error('Ошибка проверки авторизации:', error);
      setIsAuthenticated(false);
    }
  };

  // Обновляем данные при возврате на экран
  useFocusEffect(
    useCallback(() => {
      console.log('Дашборд получил фокус, обновляем данные...');
      loadDashboardDataWithoutClearing();
    }, [])
  );

  const loadDashboardData = async () => {
    try {
      console.log('Загружаем данные дашборда...');
      
      const userId = await getCurrentUserId();
      
      // Загружаем название ресторана и город из данных пользователя
      if (userId) {
        const questionnaireData = await loadUserQuestionnaire(userId);
        if (questionnaireData && questionnaireData.restaurantName && questionnaireData.restaurantName.trim()) {
          setRestaurantName(questionnaireData.restaurantName);
        } else {
          setRestaurantName('Проект');
        }
        
        // Загружаем город
        if (questionnaireData && questionnaireData.city) {
          setCity(questionnaireData.city);
        }
      } else {
        setRestaurantName('Проект');
      }
      
      // Загружаем аватар компании
      const savedProjectAvatar = await AsyncStorage.getItem('projectAvatar');
      if (savedProjectAvatar) {
        setProjectAvatarUri(savedProjectAvatar);
      }
      
      // Загружаем существующие данные
      let storedBlocks: DiagnosisBlock[] | null = null;
      let storedTasks: Task[] = [];
      
      if (userId) {
        storedBlocks = await loadUserBlocks(userId);
        storedTasks = await loadUserTasks(userId);
      } else {
        // Fallback к глобальным данным
        const blocksJson = await AsyncStorage.getItem('diagnosisBlocks');
        const tasksJson = await AsyncStorage.getItem('actionPlanTasks');
        if (blocksJson) storedBlocks = JSON.parse(blocksJson);
        if (tasksJson) storedTasks = JSON.parse(tasksJson);
      }
      
      let allBlocksCompleted: string | null = null;
      let storedPrevious: string | null = null;
      let storedCurrent: string | null = null;
      
      if (userId) {
        const dashboardData = await loadUserDashboardData(userId);
        allBlocksCompleted = dashboardData.allBlocksCompleted;
        storedPrevious = dashboardData.previousResult;
        storedCurrent = dashboardData.currentResult;
      } else {
        // Fallback к глобальным данным
        allBlocksCompleted = await AsyncStorage.getItem('dashboardAllBlocksCompleted');
        storedPrevious = await AsyncStorage.getItem('dashboardPreviousResult');
        storedCurrent = await AsyncStorage.getItem('dashboardCurrentResult');
      }
      
      if (storedBlocks) {
        const blocks = Array.isArray(storedBlocks) ? storedBlocks : JSON.parse(storedBlocks);
        // Объединяем загруженные блоки с дефолтными, чтобы показать все блоки
        const allBlocks = DEFAULT_BLOCKS.map(defaultBlock => {
          const foundBlock = blocks.find((b: DiagnosisBlock) => b.id === defaultBlock.id);
          if (foundBlock) {
            // Если блок найден, используем его данные (включая efficiency и completed)
            return {
              ...defaultBlock,
              ...foundBlock,
              // Сохраняем title и description из DEFAULT_BLOCKS
              title: defaultBlock.title,
              description: defaultBlock.description,
            };
          }
          return defaultBlock;
        });
        setBlockResults(allBlocks);
        console.log('Загружены блоки для дашборда:', allBlocks.length);
        
        // Проверяем, все ли блоки завершены
        const completedBlocks = allBlocks.filter(b => b.completed && b.efficiency !== undefined);
        const allCompleted = completedBlocks.length === DEFAULT_BLOCKS.length;
        
        if (allCompleted && completedBlocks.length > 0) {
          // Рассчитываем среднюю эффективность по всем блокам
          const avgEfficiency = Math.round(
            completedBlocks.reduce((sum, b) => sum + (b.efficiency || 0), 0) / completedBlocks.length
          );
          
          const wasAllCompleted = allBlocksCompleted === 'true';
          const previousValue = storedPrevious ? parseInt(storedPrevious, 10) : null;
          const currentValue = storedCurrent ? parseInt(storedCurrent, 10) : 0;
          
          if (!wasAllCompleted) {
            // Первое прохождение всех блоков - сохраняем только ТЕКУЩИЙ, ПРЕДЫДУЩИЙ не сохраняем
            if (userId) {
              await saveUserDashboardData(userId, {
                allBlocksCompleted: 'true',
                currentResult: avgEfficiency.toString(),
                // previousResult не сохраняем при первом прохождении
              });
            } else {
              await AsyncStorage.setItem('dashboardAllBlocksCompleted', 'true');
              await AsyncStorage.setItem('dashboardCurrentResult', avgEfficiency.toString());
              // previousResult не сохраняем при первом прохождении
            }
            setComparison({ previous: null, current: avgEfficiency, change: undefined });
          } else {
            // Последующие прохождения - проверяем, изменился ли результат
            if (avgEfficiency !== currentValue) {
              // Результат изменился - обновляем ПРЕДЫДУЩИЙ и ТЕКУЩИЙ
              const newPrevious = currentValue;
              const newCurrent = avgEfficiency;
              const change = newCurrent - newPrevious;
              
              if (userId) {
                await saveUserDashboardData(userId, {
                  previousResult: newPrevious.toString(),
                  currentResult: newCurrent.toString(),
                });
              } else {
                await AsyncStorage.setItem('dashboardPreviousResult', newPrevious.toString());
                await AsyncStorage.setItem('dashboardCurrentResult', newCurrent.toString());
              }
              setComparison({ previous: newPrevious, current: newCurrent, change });
            } else {
              // Результат не изменился - используем сохраненные значения
              const change = previousValue !== null && currentValue !== previousValue ? currentValue - previousValue : undefined;
              setComparison({ previous: previousValue, current: currentValue, change });
            }
          }
        } else {
          // Не все блоки завершены - ПРЕДЫДУЩИЙ = null, ТЕКУЩИЙ = среднее по завершенным блокам (или 0)
          const avgEfficiency = completedBlocks.length > 0 
            ? Math.round(completedBlocks.reduce((sum, b) => sum + (b.efficiency || 0), 0) / completedBlocks.length)
            : 0;
          setComparison({ previous: null, current: avgEfficiency, change: undefined });
        }
      } else {
        // Если блоков нет, показываем дефолтные
        setBlockResults(DEFAULT_BLOCKS);
        setComparison({ previous: null, current: 0, change: undefined });
        console.log('Блоков в хранилище нет, показываем дефолтные');
      }
      
      if (storedTasks && storedTasks.length > 0) {
        // Показываем только первые 3 задачи для списка
        setTasks(storedTasks.slice(0, 3));
        // Сохраняем общее количество задач для метрики
        setAllTasksCount(storedTasks.length);
        // Группируем задачи по блокам
        const groupedTasks = getTasksByBlock(storedTasks);
        setTasksByBlock(groupedTasks);
        console.log('Загружены задачи для дашборда:', storedTasks.length);
      } else {
        setTasks([]);
        setAllTasksCount(0);
        setTasksByBlock({});
        console.log('Задач для дашборда нет');
      }
      
    } catch (error) {
      console.error('Ошибка загрузки данных:', error);
      setTasks([]);
      setBlockResults(DEFAULT_BLOCKS);
      setComparison({ previous: 0, current: 0, change: 0 });
    }
  };

  const loadDashboardDataWithoutClearing = async () => {
    try {
      console.log('Загружаем данные дашборда без очистки...');
      
      const userId = await getCurrentUserId();
      
      // Загружаем название ресторана и город из данных пользователя
      if (userId) {
        const questionnaireData = await loadUserQuestionnaire(userId);
        if (questionnaireData && questionnaireData.restaurantName && questionnaireData.restaurantName.trim()) {
          setRestaurantName(questionnaireData.restaurantName);
        } else {
          setRestaurantName('Проект');
        }
        
        // Загружаем город
        if (questionnaireData && questionnaireData.city) {
          setCity(questionnaireData.city);
        }
      } else {
        setRestaurantName('Проект');
      }
      
      // Загружаем аватар компании
      const savedProjectAvatar = await AsyncStorage.getItem('projectAvatar');
      if (savedProjectAvatar) {
        setProjectAvatarUri(savedProjectAvatar);
      }
      
      // Загружаем существующие данные
      let storedBlocks: DiagnosisBlock[] | null = null;
      let storedTasks: Task[] = [];
      
      if (userId) {
        storedBlocks = await loadUserBlocks(userId);
        storedTasks = await loadUserTasks(userId);
      } else {
        // Fallback к глобальным данным
        const blocksJson = await AsyncStorage.getItem('diagnosisBlocks');
        const tasksJson = await AsyncStorage.getItem('actionPlanTasks');
        if (blocksJson) storedBlocks = JSON.parse(blocksJson);
        if (tasksJson) storedTasks = JSON.parse(tasksJson);
      }
      let allBlocksCompleted: string | null = null;
      let storedPrevious: string | null = null;
      let storedCurrent: string | null = null;
      
      if (userId) {
        const dashboardData = await loadUserDashboardData(userId);
        allBlocksCompleted = dashboardData.allBlocksCompleted;
        storedPrevious = dashboardData.previousResult;
        storedCurrent = dashboardData.currentResult;
      } else {
        allBlocksCompleted = await AsyncStorage.getItem('dashboardAllBlocksCompleted');
        storedPrevious = await AsyncStorage.getItem('dashboardPreviousResult');
        storedCurrent = await AsyncStorage.getItem('dashboardCurrentResult');
      }
      
      if (storedBlocks) {
        const blocks = Array.isArray(storedBlocks) ? storedBlocks : JSON.parse(storedBlocks);
        // Объединяем загруженные блоки с дефолтными, чтобы показать все блоки
        const allBlocks = DEFAULT_BLOCKS.map(defaultBlock => {
          const foundBlock = blocks.find((b: DiagnosisBlock) => b.id === defaultBlock.id);
          if (foundBlock) {
            // Если блок найден, используем его данные (включая efficiency и completed)
            return {
              ...defaultBlock,
              ...foundBlock,
              // Сохраняем title и description из DEFAULT_BLOCKS
              title: defaultBlock.title,
              description: defaultBlock.description,
            };
          }
          return defaultBlock;
        });
        setBlockResults(allBlocks);
        console.log('Загружены блоки для дашборда:', allBlocks.length);
        
        // Проверяем, все ли блоки завершены
        const completedBlocks = allBlocks.filter(b => b.completed && b.efficiency !== undefined);
        const allCompleted = completedBlocks.length === DEFAULT_BLOCKS.length;
        
        if (allCompleted && completedBlocks.length > 0) {
          // Рассчитываем среднюю эффективность по всем блокам
          const avgEfficiency = Math.round(
            completedBlocks.reduce((sum, b) => sum + (b.efficiency || 0), 0) / completedBlocks.length
          );
          
          const wasAllCompleted = allBlocksCompleted === 'true';
          const previousValue = storedPrevious ? parseInt(storedPrevious, 10) : null;
          const currentValue = storedCurrent ? parseInt(storedCurrent, 10) : 0;
          
          if (!wasAllCompleted) {
            // Первое прохождение всех блоков - сохраняем только ТЕКУЩИЙ, ПРЕДЫДУЩИЙ не сохраняем
            if (userId) {
              await saveUserDashboardData(userId, {
                allBlocksCompleted: 'true',
                currentResult: avgEfficiency.toString(),
                // previousResult не сохраняем при первом прохождении
              });
            } else {
              await AsyncStorage.setItem('dashboardAllBlocksCompleted', 'true');
              await AsyncStorage.setItem('dashboardCurrentResult', avgEfficiency.toString());
              // previousResult не сохраняем при первом прохождении
            }
            setComparison({ previous: null, current: avgEfficiency, change: undefined });
          } else {
            // Последующие прохождения - проверяем, изменился ли результат
            if (avgEfficiency !== currentValue) {
              // Результат изменился - обновляем ПРЕДЫДУЩИЙ и ТЕКУЩИЙ
              const newPrevious = currentValue;
              const newCurrent = avgEfficiency;
              const change = newCurrent - newPrevious;
              
              if (userId) {
                await saveUserDashboardData(userId, {
                  previousResult: newPrevious.toString(),
                  currentResult: newCurrent.toString(),
                });
              } else {
                await AsyncStorage.setItem('dashboardPreviousResult', newPrevious.toString());
                await AsyncStorage.setItem('dashboardCurrentResult', newCurrent.toString());
              }
              setComparison({ previous: newPrevious, current: newCurrent, change });
            } else {
              // Результат не изменился - используем сохраненные значения
              const change = previousValue !== null && currentValue !== previousValue ? currentValue - previousValue : undefined;
              setComparison({ previous: previousValue, current: currentValue, change });
            }
          }
        } else {
          // Не все блоки завершены - ПРЕДЫДУЩИЙ = null, ТЕКУЩИЙ = среднее по завершенным блокам (или 0)
          const avgEfficiency = completedBlocks.length > 0 
            ? Math.round(completedBlocks.reduce((sum, b) => sum + (b.efficiency || 0), 0) / completedBlocks.length)
            : 0;
          setComparison({ previous: null, current: avgEfficiency, change: undefined });
        }
      } else {
        // Если блоков нет, показываем дефолтные
        setBlockResults(DEFAULT_BLOCKS);
        setComparison({ previous: null, current: 0, change: undefined });
        console.log('Блоков в хранилище нет, показываем дефолтные');
      }

      // Загружаем задачи
      if (storedTasks && storedTasks.length > 0) {
        setTasks(storedTasks.slice(0, 3)); // Показываем только первые 3 задачи
        setAllTasksCount(storedTasks.length); // Сохраняем общее количество задач
        // Группируем задачи по блокам
        const groupedTasks = getTasksByBlock(storedTasks);
        setTasksByBlock(groupedTasks);
        console.log('Загружены задачи для дашборда:', storedTasks.length);
      } else {
        setTasks([]);
        setAllTasksCount(0);
        setTasksByBlock({});
        console.log('Задач для дашборда нет');
      }
      
    } catch (error) {
      console.error('Ошибка загрузки данных дашборда:', error);
    }
  };

  // Функция для получения иконки блока
  const getBlockIcon = (blockId: string): keyof typeof Ionicons.glyphMap => {
    const iconMap: Record<string, keyof typeof Ionicons.glyphMap> = {
      'concept': 'bulb-outline',
      'finance': 'cash-outline',
      'management': 'people-outline',
      'menu': 'restaurant-outline',
      'marketing': 'megaphone-outline',
      'operations': 'settings-outline',
      'client_experience': 'happy-outline',
      'infrastructure': 'build-outline',
      'risks': 'shield-outline',
      'strategy': 'trending-up-outline',
    };
    return iconMap[blockId] || 'cube-outline';
  };

  const getEfficiencyColor = (efficiency?: number): { bg: string; text: string; border?: string } => {
    if (efficiency === undefined || efficiency === null) {
      return { bg: COLORS.gray, text: COLORS.darkGray };
    }
    
    // Чем ниже эффективность, тем тревожнее цвет
    if (efficiency >= 80) {
      // Высокая эффективность - спокойный зеленоватый
      return { bg: '#E8F5E9', text: COLORS.green, border: '#81C784' };
    } else if (efficiency >= 60) {
      // Средняя эффективность - нейтральный голубоватый
      return { bg: '#E3F2FD', text: COLORS.blue, border: '#64B5F6' };
    } else if (efficiency >= 40) {
      // Низкая эффективность - предупреждающий оранжевый
      return { bg: '#FFF3E0', text: '#F57C00', border: '#FFB74D' };
    } else {
      // Очень низкая эффективность - тревожный красноватый
      return { bg: '#FFEBEE', text: '#D32F2F', border: '#E57373' };
    }
  };


  const scrollToTop = () => {
    scrollViewRef.current?.scrollTo({ y: 0, animated: true });
  };

  const handleScroll = (event: any) => {
    const offsetY = event.nativeEvent.contentOffset.y;
    setShowScrollButton(offsetY > 500);
  };

  return (
    <View style={styles.container}>
      <ScrollView 
        ref={scrollViewRef} 
        style={styles.scrollView}
        onScroll={handleScroll}
        scrollEventThrottle={16}
      >
        {/* Секция профиля проекта */}
        <View style={[styles.section, styles.profileSection]}>
          <View style={styles.profileInfo}>
            {/* Аватар компании */}
            <View style={styles.avatarContainer}>
              {projectAvatarUri ? (
                <Image source={{ uri: projectAvatarUri }} style={styles.avatarImage} />
              ) : (
                <View style={styles.avatarPlaceholder}>
                  <Ionicons name="business" size={32} color={palette.gray400} />
                </View>
              )}
            </View>
            
            {/* Название и город */}
            <View style={styles.projectInfo}>
              <Text style={styles.projectName}>Проект</Text>
              <View style={styles.cityContainer}>
                <Text style={styles.cityText}>{city || 'город'}</Text>
                {cityIconSvg && (
                  <View style={styles.cityIconContainer}>
                    <SvgXml xml={cityIconSvg} width={16} height={16} />
                  </View>
                )}
              </View>
            </View>
          </View>
          
          {/* Кнопка Помощь PELBY */}
          <AnimatedPressable style={styles.helpButton}>
            {helpButtonIconSvg ? (
              <View style={styles.helpButtonIconContainer}>
                <SvgXml xml={helpButtonIconSvg} width={18} height={18} />
              </View>
            ) : null}
            <Text style={styles.helpButtonText}>Помощь PELBY</Text>
          </AnimatedPressable>
        </View>

        {/* Секция Общая эффективность */}
        <View style={[styles.section, styles.efficiencySection]}>
          {/* Заголовок с иконками */}
          <View style={styles.efficiencyHeader}>
            <View style={styles.efficiencyTitleContainer}>
              <Text style={styles.efficiencyTitle}>Общая эффективность</Text>
              {infoIconSvg && (
                <AnimatedPressable style={styles.infoIconButton}>
                  <SvgXml xml={infoIconSvg} width={20} height={20} />
                </AnimatedPressable>
              )}
            </View>
            <View style={styles.efficiencyIcons}>
              {refreshIconSvg && (
                <AnimatedPressable style={styles.iconButton}>
                  <SvgXml xml={refreshIconSvg} width={36} height={36} />
                </AnimatedPressable>
              )}
              {addIconSvg && (
                <AnimatedPressable style={styles.iconButton}>
                  <SvgXml xml={addIconSvg} width={36} height={36} />
                </AnimatedPressable>
              )}
            </View>
          </View>

          {/* Серая полоса под заголовком */}
          <View style={styles.efficiencyDivider} />

          {/* Спидометр */}
          <View style={styles.gaugeContainer}>
            <BlockGauge 
              blockResults={blockResults}
              currentValue={comparison.current || 0}
            />
          </View>

          {/* Текст "X/10 БЛОКОВ" */}
          <Text style={styles.blocksCountText}>
            {blockResults.filter(b => b.completed).length}/{DEFAULT_BLOCKS.length} БЛОКОВ
          </Text>

          {/* Метрики */}
          <View style={styles.metricsContainer}>
            {/* Слабых блоков */}
            <View style={styles.metricItem}>
              <Text style={styles.metricLabel}>Слабых блоков</Text>
              <View style={[styles.metricBadge, styles.weakBlocksBadge]}>
                <Text style={styles.weakBlocksBadgeText}>
                  {blockResults.filter(b => b.completed && (b.efficiency || 0) < 38).length}
                </Text>
              </View>
            </View>

            {/* Прошлая диагностика */}
            <View style={styles.metricItem}>
              <Text style={styles.metricLabel}>Прошлая диагностика</Text>
              <View style={styles.metricValueRow}>
                <View style={[styles.metricBadge, styles.previousDiagnosisBadge]}>
                  <Text style={styles.previousDiagnosisBadgeText}>
                    {comparison.previous !== null ? `${comparison.previous}%` : '—'}
                  </Text>
                </View>
                {comparison.change !== undefined && comparison.change !== 0 && (
                  <View style={styles.changeIndicator}>
                    <Ionicons 
                      name={comparison.change > 0 ? "arrow-up" : "arrow-down"} 
                      size={12} 
                      color={COLORS.red} 
                    />
                    <Text style={styles.changeText}>
                      {Math.abs(comparison.change)}%
                    </Text>
                  </View>
                )}
              </View>
            </View>

            {/* Всего задач */}
            <View style={styles.metricItem}>
              <Text style={styles.metricLabel}>Всего задач</Text>
              <View style={[styles.metricBadge, styles.tasksBadge]}>
                <Text style={styles.tasksBadgeText}>
                  {allTasksCount}
                </Text>
              </View>
            </View>
          </View>

          {/* Кнопка "План улучшений" */}
          <AnimatedPressable 
            style={styles.improvementPlanButton}
            onPress={() => navigation.navigate('ActionPlan')}
          >
            <Text style={styles.improvementPlanButtonText}>План улучшений</Text>
          </AnimatedPressable>
        </View>

        {/* Секция Оценка бизнес-направлений */}
        <View style={[styles.section, styles.businessAssessmentSection]}>
          {/* Заголовок с иконкой фильтра */}
          <View style={styles.businessAssessmentHeader}>
            <Text style={styles.businessAssessmentTitle}>Оценка бизнес-направлений</Text>
            <AnimatedPressable style={styles.filterButton}>
              <Ionicons name="filter-outline" size={20} color={palette.gray600} />
            </AnimatedPressable>
          </View>

          {/* Сетка карточек блоков */}
          <View style={styles.blocksGridNew}>
            {blockResults.map((block) => {
              const efficiency = block.efficiency ?? 0;
              const colors = getEfficiencyColor(block.efficiency);
              const blockTasks = tasksByBlock[block.id] || { total: 0, completed: 0 };
              const iconName = getBlockIcon(block.id);
              
              // Определяем цвет процента
              let efficiencyColor = palette.gray600;
              if (block.completed && block.efficiency !== undefined) {
                if (block.efficiency >= 78) {
                  efficiencyColor = palette.success; // Зеленый
                } else if (block.efficiency >= 38) {
                  efficiencyColor = palette.warning; // Оранжевый
                } else {
                  efficiencyColor = palette.error; // Красный
                }
              }

              return (
                <AnimatedPressable
                  key={block.id}
                  style={styles.businessBlockCard}
                  onPress={() => {
                    if (navigation) {
                      navigation.navigate('BlockDetail', { blockId: block.id });
                    }
                  }}
                >
                  {/* Иконка блока */}
                  <View style={[styles.blockIconContainer, { backgroundColor: colors.bg }]}>
                    <Ionicons name={iconName} size={24} color={colors.text} />
                  </View>

                  {/* Процент эффективности */}
                  <Text style={[styles.blockEfficiencyPercent, { color: efficiencyColor }]}>
                    {block.completed && block.efficiency !== undefined ? `${block.efficiency}%` : '—'}
                  </Text>

                  {/* Описание блока */}
                  <Text style={styles.blockDescription} numberOfLines={2}>
                    {block.description}
                  </Text>

                  {/* Количество задач */}
                  <View style={styles.blockTasksContainer}>
                    <Ionicons name="list-outline" size={14} color={palette.gray600} />
                    <Text style={styles.blockTasksText}>
                      {blockTasks.total} {blockTasks.total === 1 ? 'задача' : blockTasks.total < 5 ? 'задачи' : 'задач'}
                    </Text>
                  </View>
                </AnimatedPressable>
              );
            })}
          </View>
        </View>

        {/* Секция призыва к действию */}
        <View style={[styles.section, styles.ctaSection]}>
          <View style={styles.ctaCard}>
            <Text style={styles.ctaTitle}>Провалы в эффективности?</Text>
            <Text style={styles.ctaDescription}>
              Выявите слабые места в вашем бизнесе и получите персональные рекомендации по улучшению
            </Text>
            <AnimatedPressable 
              style={styles.ctaButton}
              onPress={() => {
                if (navigation) {
                  navigation.navigate('SelfDiagnosisBlocks');
                }
              }}
            >
              <Text style={styles.ctaButtonText}>Улучшить эффективность</Text>
            </AnimatedPressable>
          </View>
        </View>
      </ScrollView>
      <ScrollToTopButton onPress={scrollToTop} visible={showScrollButton} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: palette.background,
  },
  scrollView: {
    flex: 1,
  },
  // Секция профиля проекта
  profileSection: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingRight: 0,
    paddingVertical: spacing.md,
    marginTop: spacing.xxl,
    marginBottom: spacing.lg,
    marginRight: spacing.md,
    marginLeft: spacing.sm,
  },
  profileInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    transform: [{ translateY: -2 }],
  },
  avatarContainer: {
    marginRight: 2,
  },
  avatarImage: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: palette.gray100,
  },
  avatarPlaceholder: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: palette.gray100,
    justifyContent: 'center',
    alignItems: 'center',
  },
  projectInfo: {
    flex: 1,
    transform: [{ translateY: -2 }],
  },
  projectName: {
    fontSize: 18,
    fontWeight: '400',
    color: palette.midnightBlue,
    marginBottom: spacing.xxs,
    marginTop: 0,
    marginLeft: -1,
  },
  cityContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  cityText: {
    fontSize: 14,
    color: palette.gray600,
    marginRight: 2,
  },
  cityIconContainer: {
    marginLeft: 2,
  },
  helpButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: palette.primaryOrange,
    paddingLeft: 6,
    paddingRight: 6,
    paddingVertical: 6,
    height: 32,
    borderRadius: 999,
    alignSelf: 'center',
    marginLeft: -1,
  },
  helpButtonIconContainer: {
    marginRight: 2,
    marginLeft: 1,
  },
  helpButtonText: {
    fontSize: 14,
    fontWeight: '300',
    color: palette.white,
    lineHeight: 16,
    transform: [{ translateY: -1 }],
  },
  section: {
    marginHorizontal: spacing.md,
    marginBottom: spacing.md,
  },
  // Секция Общая эффективность
  efficiencySection: {
    backgroundColor: palette.white,
    borderRadius: radii.xl,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.lg,
    marginBottom: spacing.lg,
    marginTop: -(spacing.md + 5),
    shadowColor: palette.midnightBlue,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 3,
  },
  efficiencyHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: -10,
    marginBottom: spacing.sm,
  },
  efficiencyTitleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  efficiencyTitle: {
    fontSize: 17,
    fontWeight: '400',
    color: palette.midnightBlue,
    marginRight: 2,
  },
  infoIconButton: {
    marginLeft: 2,
  },
  efficiencyIcons: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
  },
  iconButton: {
    // Убрали padding, чтобы иконки выравнивались как метрики ниже
  },
  efficiencyDivider: {
    height: 1,
    backgroundColor: '#E2E4E9',
    marginLeft: 4,
    marginRight: 4,
    marginBottom: (spacing.lg - spacing.sm) / 2,
  },
  gaugeContainer: {
    alignItems: 'center',
    marginTop: spacing.sm / 2,
    marginBottom: spacing.md,
    overflow: 'visible',
  },
  blocksCountText: {
    fontSize: 14,
    fontWeight: '600',
    color: palette.gray600,
    textAlign: 'center',
    marginTop: spacing.sm,
    marginBottom: spacing.lg,
    letterSpacing: 0.5,
  },
  metricsContainer: {
    marginBottom: spacing.lg,
  },
  metricItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.md,
  },
  metricLabel: {
    fontSize: 14,
    fontWeight: '400',
    color: palette.midnightBlue,
    flex: 1,
  },
  metricValueRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
  },
  metricBadge: {
    minWidth: 50,
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: radii.pill,
    alignItems: 'center',
    justifyContent: 'center',
  },
  weakBlocksBadge: {
    backgroundColor: '#F8C9D2',
  },
  weakBlocksBadgeText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#710E21',
  },
  previousDiagnosisBadge: {
    backgroundColor: palette.success,
  },
  previousDiagnosisBadgeText: {
    fontSize: 13,
    fontWeight: '600',
    color: palette.white,
  },
  tasksBadge: {
    backgroundColor: palette.gray200,
  },
  tasksBadgeText: {
    fontSize: 13,
    fontWeight: '600',
    color: palette.midnightBlue,
  },
  changeIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: spacing.xs,
  },
  changeText: {
    fontSize: 12,
    fontWeight: '600',
    marginLeft: spacing.xs,
  },
  improvementPlanButton: {
    backgroundColor: '#375DFB',
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    borderRadius: radii.md,
    alignItems: 'center',
    justifyContent: 'center',
  },
  improvementPlanButtonText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#EBF1FF',
  },
  // Секция Оценка бизнес-направлений
  businessAssessmentSection: {
    backgroundColor: palette.white,
    borderRadius: radii.xl,
    padding: spacing.lg,
    marginBottom: spacing.lg,
    shadowColor: palette.midnightBlue,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 3,
  },
  businessAssessmentHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.lg,
  },
  businessAssessmentTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: palette.midnightBlue,
  },
  filterButton: {
    padding: spacing.xs,
  },
  blocksGridNew: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  businessBlockCard: {
    width: '48%',
    backgroundColor: palette.white,
    borderRadius: radii.md,
    padding: spacing.md,
    marginBottom: spacing.md,
    borderWidth: 1,
    borderColor: palette.gray200,
    shadowColor: palette.midnightBlue,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  blockIconContainer: {
    width: 48,
    height: 48,
    borderRadius: radii.md,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  blockEfficiencyPercent: {
    fontSize: 20,
    fontWeight: '700',
    marginBottom: spacing.xs,
  },
  blockDescription: {
    fontSize: 12,
    fontWeight: '400',
    color: palette.gray600,
    marginBottom: spacing.sm,
    lineHeight: 16,
  },
  blockTasksContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
  },
  blockTasksText: {
    fontSize: 12,
    fontWeight: '400',
    color: palette.gray600,
  },
  // Секция призыва к действию
  ctaSection: {
    marginBottom: spacing.lg,
  },
  ctaCard: {
    backgroundColor: palette.midnightBlue,
    borderRadius: radii.xl,
    padding: spacing.xl,
    shadowColor: palette.midnightBlue,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.15,
    shadowRadius: 16,
    elevation: 6,
  },
  ctaTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: palette.white,
    marginBottom: spacing.sm,
  },
  ctaDescription: {
    fontSize: 14,
    fontWeight: '400',
    color: palette.gray300,
    lineHeight: 20,
    marginBottom: spacing.lg,
  },
  ctaButton: {
    backgroundColor: palette.primaryOrange,
    borderRadius: radii.md,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    alignItems: 'center',
    justifyContent: 'center',
  },
  ctaButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: palette.white,
  },
});
